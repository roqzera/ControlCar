﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using PimForms.Classes;

namespace PimForms.Dao
{
    public class OcupanteDao
    {
        MySqlCommand cmd = new MySqlCommand();
        ConexaoBanco conexao = new ConexaoBanco();
        MySqlConnection mySqlConnection;

        //private string strConn = @"server=localhost;database=controlcar;userid=ja_server;password=ja23;";

        
    }
}
