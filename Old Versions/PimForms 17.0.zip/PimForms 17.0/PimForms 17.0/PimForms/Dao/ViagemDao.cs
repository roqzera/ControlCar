﻿using MySql.Data.MySqlClient;
using PimForms.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PimForms.Dao
{
    class ViagemDao
    {
        MySqlCommand cmd = new MySqlCommand();
        ConexaoBanco conexao = new ConexaoBanco();
        MySqlConnection mySqlConnection;
        FuncionarioDao funcionarioDao = new FuncionarioDao();

        private string strConn = @"server=localhost;database=controlcar;userid=ja_server;password=ja23;";

        public void AdicionarViagem(Viagem viagem)
        {
            //Comando Sql: insert, update, delete

            cmd.CommandText = "INSERT INTO viagem (data_saida, data_retorno, destino, valor_adiantamento, km_inicial, km_final, id_veiculo, id_funcionario) " +
                "VALUES (@DataSaida, @DataRetorno, @Destino, @ValorAdiantamento, @KmInicial, @KmFinal, @IdVeiculo, @IdFuncionario)";

            //Parametros
            cmd.Parameters.AddWithValue("@DataSaida", viagem.DataSaida);
            cmd.Parameters.AddWithValue("@DataRetorno", viagem.DataRetorno);
            cmd.Parameters.AddWithValue("@Destino", viagem.Destino);
            cmd.Parameters.AddWithValue("@ValorAdiantamento", viagem.ValorAdiantamento);
            cmd.Parameters.AddWithValue("@KmInicial", viagem.KmInicial);
            cmd.Parameters.AddWithValue("@KmFinal", viagem.KmFinal);
            cmd.Parameters.AddWithValue("@IdVeiculo", viagem.IdVeiculo);
            cmd.Parameters.AddWithValue("@IdFuncionario", viagem.IdFuncionario);

            try
            {
                //Conectar com o banco
                cmd.Connection = conexao.Conectar();
                //Executar Comando
                cmd.ExecuteNonQuery();
                //Desconectar
                conexao.Desconectar();
                //Mostrar mensagem de sucesso/erro
                MessageBox.Show("Cadastro realizado com sucesso!");
            }

            catch (MySqlException)
            {
                //MessageBox.Show("Erro ao tentar se conectar com o banco de dados");
                //throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }

        public List<Viagem> ListarViagem()
        {
            List<Viagem> viagens = new List<Viagem>();
            MySqlConnection conn = new MySqlConnection(strConn); //comando para obter o número de linhas                                                                                                                               //existentes no BD      
            string sql1 = "select v.id_funcionario, v.id_veiculo, v.data_saida, v.data_retorno, v.destino, v.valor_adiantamento, v.km_inicial, v.km_final, v.acompanhante1, v.acompanhante2, v.acompanhante3, f.nome as motorista, veic.Placa from viagem v inner join funcionario f on v.id_funcionario = f.id_funcionario inner join veiculo veic on v.id_veiculo = veic.id_veiculo";
            MySqlCommand cmd1 = new MySqlCommand(sql1.ToString(), conn);
            conn.Open();
            MySqlDataReader rdr = cmd1.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Viagem v = new Viagem()
                    {
                        DataSaida = Convert.ToDateTime(rdr["v.data_saida"]),
                        DataRetorno = Convert.ToDateTime(rdr["v.data_retorno"]),
                        Destino = Convert.ToString(rdr["v.destino"]),
                        ValorAdiantamento = Convert.ToDecimal(rdr["v.valor_adiantamento"]),
                        KmInicial = Convert.ToDecimal(rdr["v.km_inicial"]),
                        KmFinal = Convert.ToDecimal(rdr["v.km_final"]),
                        IdFuncionario = Convert.ToInt32(rdr["v.id_funcionario"]),
                        funcionario = funcionarioDao.BuscarFuncionario("id_funcionario", Convert.ToString(rdr["v.id_funcionario"]));
                        IdVeiculo = Convert.ToInt32(rdr["v.id_veiculo"]),
                        Acompanhante1 = Convert.ToString(rdr["v.acompanhante1"]),
                        Acompanhante2 = Convert.ToString(rdr["v.acompanhante2"]),
                        Acompanhante3 = Convert.ToString(rdr["v.acompanhante3"]),
                    };

                    viagens.Add(v);
                }
            }
            conn.Close();
            return viagens;
        }

        public string FiltrarViagemVeiculo(string placa)
        {

            string strMysql = "SELECT * FROM veiculo_viagem WHERE placa = '"+placa+"';";
            //cmd.Parameters.AddWithValue("@placa", placa);

            return strMysql;
        }
        public string FiltrarViagemFuncionario(string matricula)
        {

            string strMysql = "SELECT * FROM funcionario_viagem WHERE matricula = '"+matricula+"';";
            //cmd.Parameters.AddWithValue("@matricula", matricula);

            return strMysql;
        }
    }
}
