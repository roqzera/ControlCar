﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PimForms.Classes;
using PimForms.Dao;

namespace PimForms.Formulários
{
    public partial class CadastrarOcupantes : Form
    {
        public int cont = 0;

        public CadastrarOcupantes()
        {
            InitializeComponent();    
        }

        FuncionarioDao funcionarioDao = new FuncionarioDao();

        private void CadastrarOcupantes_Load(object sender, EventArgs e)
        {
        }

        private void BtnAdicionar_Click(object sender, EventArgs e)
        {

        }

        private void BtnAdicionarOcupante_Click(object sender, EventArgs e)
        {
            FuncionarioDao funcionarioDao = new FuncionarioDao();
            string nome = funcionarioDao.BuscarAcompanhante(txtMatriculaOcupante.Text);
            
            if(cont == 0)
            {
                lblOcupante1.Text = nome;
            }
            else
            {
                if(cont == 1)
                {
                    lblOcupante2.Text = nome;
                }
                else
                {
                    if(cont == 2)
                    {
                        lblOcupante3.Text = nome;
                    }
                }
            }

            cont++;

            if(cont == 4)
            {
                MessageBox.Show("Não é possível adicionar mais acompanhantes. Apenas três acompanhantes são permitidos por viagem.");
            }
        }

        private void BtnConfirmar_Click(object sender, EventArgs e)
        {
            CadastrarViagem cadastrarViagem = new CadastrarViagem();
            /*
            if ((lblOcupante1.Text != "") && (lblOcupante2.Text == "") && (lblOcupante3.Text == ""))
            {
                cadastrarViagem.lblOcupantesAdicionados.Text = "Um acompanhante foi adicionado a esta viagem.";
            }
            else
            {
                if((lblOcupante1.Text != "") && (lblOcupante2.Text != "") && (lblOcupante3.Text == ""))
                {
                    cadastrarViagem.lblOcupantesAdicionados.Text = "Dois acompanhantes foram adicionados a esta viagem.";
                }
                else
                {
                    if((lblOcupante1.Text != "") && (lblOcupante2.Text != "") && (lblOcupante3.Text != ""))
                    {
                        cadastrarViagem.lblOcupantesAdicionados.Text = "Três acompanhantes foram adicionados a esta viagem.";
                    }
                }
            }
            */

            if (cont == 1)
            {
                lblQuantidadeDeAcompanhantes.ForeColor = Color.OliveDrab;
                lblQuantidadeDeAcompanhantes.Text = "Um acompanhante foi adicionado a esta viagem.";
            }
            else
            {
                if (cont == 2)
                {
                    lblQuantidadeDeAcompanhantes.ForeColor = Color.OliveDrab;
                    lblQuantidadeDeAcompanhantes.Text = "Dois acompanhantes foram adicionados a esta viagem.";
                }
                else
                {
                    if (cont == 3)
                    {
                        lblQuantidadeDeAcompanhantes.ForeColor = Color.OliveDrab;
                        lblQuantidadeDeAcompanhantes.Text = "Três acompanhantes foram adicionados a esta viagem.";
                    }
                }
            }
        }

        private void Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
