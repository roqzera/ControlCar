﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PimForms.Classes;
using PimForms.Dao;

namespace PimForms.Formulários
{
    public partial class ListarViagem : Form
    {
        public ListarViagem()
        {
            InitializeComponent();
        }

        public void Listar()
        {
            FuncionarioDao funcionarioDao = new FuncionarioDao();
            int idFuncionario = Convert.ToInt32(funcionarioDao.BuscarIdFuncionario("matricula", toolStripTextBoxMatricula.Text));

            VeiculoDao veiculoDao = new VeiculoDao();
            int idVeiculo = Convert.ToInt32(veiculoDao.BuscarIdVeiculo(toolStripTextBoxPlaca.Text));

            ViagemDao viagemDao = new ViagemDao();
            dataGridListar.DataSource = viagemDao.ListarViagem(idFuncionario, idVeiculo);
        }
    }
}
