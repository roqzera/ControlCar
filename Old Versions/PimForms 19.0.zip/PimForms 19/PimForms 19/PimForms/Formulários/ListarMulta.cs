﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PimForms.Classes;
using PimForms.SubMenus;
using PimForms.Formulários;

namespace PimForms.Formulários
{
    public partial class ListarMulta : Form
    {
        public ListarMulta()
        {
            InitializeComponent();
            Listar();
        }

        Formularios form = new Formularios();
        MultaDAO mult = new MultaDAO();
        AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
        private void ListarMulta_Load(object sender, EventArgs e)
        {
        }

        /*
        public void Listar()
        {
            MultaDAO multaDao = new MultaDAO();
            dataGridListar.DataSource = multaDao.ListarMultas();

        }
        */

        public void Listar()
        {
            MultaDAO multaDAO = new MultaDAO();
            //strMysql armazena o retorno do método BuscarFuncionario(), que é uma string de comando MySql. 
            string strMysql = multaDAO.ListarMulta();
            // A string strMysql é passada por parâmetro para que o método ExibirNoDataGridView() possa fazer a conexão com o banco e exibir os dados buscados no DataGridView
            dataGridListar.DataSource = multaDAO.ExibirNoDataGridView(strMysql);
            //dataGridListar.Columns["id_funcionario"].Visible = false;
        }
        private void ToolStripButtonPesquisar_Click(object sender, EventArgs e)
        {
            string placa = Convert.ToString(txtPesquisa.Text);

            MultaDAO multaDAO = new MultaDAO();
            dataGridListar.DataSource = multaDAO.BuscarMultaLista(placa);
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            Listar();
        }

        private void ToolStripButtonListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        private void ToolStripButtonEditar_Click(object sender, EventArgs e)
        {
            /*
            EditarCadastroMulta editarCadastroMulta = new EditarCadastroMulta();

            if (dataGridListar.SelectedRows.Count > 0)
            {
                editarCadastroMulta.txtNumMatriculaEditarCadastro.Text = dataGridListar.CurrentRow.Cells["numero_infracao"].Value.ToString();
                editarCadastroMulta.txtNumeroDaInfracaoEditarCadastro.Text = dataGridListar.CurrentRow.Cells["numero_infracao"].Value.ToString();
                editarCadastroMulta.maskDataEditarCadastro.Text = dataGridListar.CurrentRow.Cells["data_multa"].Value.ToString();
                editarCadastroMulta.txtValorEditarCadastro.Text = dataGridListar.CurrentRow.Cells["valor"].Value.ToString();
                editarCadastroMulta.lblId.Text = dataGridListar.CurrentRow.Cells["id_multa"].Value.ToString();

            }

            editarCadastroMulta.Show();
            */
        }

        /*private void ToolStripButtonEditar_Click_1(object sender, EventArgs e)
        {
            // Abre o form EditarCadastroFuncionario
            EditarCadastroMulta editarCadastroMulta = new EditarCadastroMulta();

            if (dataGridListar.SelectedRows.Count > 0)
            {
                MultaDAO multaDAO = new MultaDAO();

                editarCadastroMulta.maskedPlaca.Text = dataGridListar.CurrentRow.Cells["placa"].Value.ToString();
                editarCadastroMulta.txtNumeroDaInfracaoEditarCadastro.Text = dataGridListar.CurrentRow.Cells["NumeroDaInfracao"].Value.ToString();
                editarCadastroMulta.txtValorEditarCadastro.Text = dataGridListar.CurrentRow.Cells["valor"].Value.ToString();
                editarCadastroMulta.maskDataEditarCadastro.Text = dataGridListar.CurrentRow.Cells["Data"].Value.ToString();
                editarCadastroMulta.lblERRO.Text = multaDAO.BuscarIdMulta(dataGridListar.CurrentRow.Cells["placa"].Value.ToString());

            }

            editarCadastroMulta.Show();
        }*/

        private void ToolStripButtonExcluir_Click(object sender, EventArgs e)
        {
            string idMulta;
            if (dataGridListar.SelectedRows.Count > 0)
            {
                MultaDAO multa = new MultaDAO();
                idMulta = multa.BuscarIdMulta(dataGridListar.CurrentRow.Cells["placa"].Value.ToString());
                multa.ExcluirMulta(Convert.ToString(idMulta));
            }

            Listar();
        }

        private void ToolStripButtonListar_Click_1(object sender, EventArgs e)
        {
            Listar();
        }

        private void ToolStripButtonPesquisar_Click_1(object sender, EventArgs e)
        {
            string placa = Convert.ToString(txtPesquisa.Text);

            MultaDAO multaDAO = new MultaDAO();
            dataGridListar.DataSource = multaDAO.BuscarMultaLista(placa);
        }

        private void ToolStripTextBoxPlacaMulta_Click(object sender, EventArgs e)
        {

        }
    }
}
