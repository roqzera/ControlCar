﻿namespace PimForms.Formulários
{
    partial class EditarCadastroFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatriculaEditarCadastro = new System.Windows.Forms.TextBox();
            this.txtNomeEditarCadastro = new System.Windows.Forms.TextBox();
            this.txtNumeroCNHEditar = new System.Windows.Forms.TextBox();
            this.txtCargoEditarCadastro = new System.Windows.Forms.TextBox();
            this.txtEmailEditarCadastro = new System.Windows.Forms.TextBox();
            this.maskCPFEditarCadastro = new System.Windows.Forms.MaskedTextBox();
            this.maskDataNascimentoEditar = new System.Windows.Forms.MaskedTextBox();
            this.maskTelefoneEditarCadastro = new System.Windows.Forms.MaskedTextBox();
            this.maskValidadeCNHEditarCadastro = new System.Windows.Forms.MaskedTextBox();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblCpf = new System.Windows.Forms.Label();
            this.lblDataDeNascimento = new System.Windows.Forms.Label();
            this.lblTelefone = new System.Windows.Forms.Label();
            this.lblCargo = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblNumeroCnh = new System.Windows.Forms.Label();
            this.lblCategoriaDaCnh = new System.Windows.Forms.Label();
            this.lblValidadeCnh = new System.Windows.Forms.Label();
            this.btnEditarCadastroFuncionario = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.labeltesteErro = new System.Windows.Forms.Label();
            this.comboBoxCategoriaCnhEditar = new System.Windows.Forms.ComboBox();
            this.lblMesagemObrigatoriedade = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblTituloForm = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMatriculaEditarCadastro
            // 
            this.txtMatriculaEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMatriculaEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatriculaEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.txtMatriculaEditarCadastro.Location = new System.Drawing.Point(64, 71);
            this.txtMatriculaEditarCadastro.Margin = new System.Windows.Forms.Padding(2);
            this.txtMatriculaEditarCadastro.Name = "txtMatriculaEditarCadastro";
            this.txtMatriculaEditarCadastro.ReadOnly = true;
            this.txtMatriculaEditarCadastro.Size = new System.Drawing.Size(352, 24);
            this.txtMatriculaEditarCadastro.TabIndex = 0;
            // 
            // txtNomeEditarCadastro
            // 
            this.txtNomeEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNomeEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.txtNomeEditarCadastro.Location = new System.Drawing.Point(64, 135);
            this.txtNomeEditarCadastro.Margin = new System.Windows.Forms.Padding(2);
            this.txtNomeEditarCadastro.Name = "txtNomeEditarCadastro";
            this.txtNomeEditarCadastro.Size = new System.Drawing.Size(352, 24);
            this.txtNomeEditarCadastro.TabIndex = 1;
            this.txtNomeEditarCadastro.TextChanged += new System.EventHandler(this.TxtNomeEditarCadastro_TextChanged);
            // 
            // txtNumeroCNHEditar
            // 
            this.txtNumeroCNHEditar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNumeroCNHEditar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumeroCNHEditar.ForeColor = System.Drawing.Color.DimGray;
            this.txtNumeroCNHEditar.Location = new System.Drawing.Point(482, 199);
            this.txtNumeroCNHEditar.Margin = new System.Windows.Forms.Padding(2);
            this.txtNumeroCNHEditar.Name = "txtNumeroCNHEditar";
            this.txtNumeroCNHEditar.Size = new System.Drawing.Size(352, 24);
            this.txtNumeroCNHEditar.TabIndex = 7;
            // 
            // txtCargoEditarCadastro
            // 
            this.txtCargoEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCargoEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCargoEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.txtCargoEditarCadastro.Location = new System.Drawing.Point(482, 71);
            this.txtCargoEditarCadastro.Margin = new System.Windows.Forms.Padding(2);
            this.txtCargoEditarCadastro.Name = "txtCargoEditarCadastro";
            this.txtCargoEditarCadastro.Size = new System.Drawing.Size(352, 24);
            this.txtCargoEditarCadastro.TabIndex = 5;
            // 
            // txtEmailEditarCadastro
            // 
            this.txtEmailEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmailEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.txtEmailEditarCadastro.Location = new System.Drawing.Point(482, 135);
            this.txtEmailEditarCadastro.Margin = new System.Windows.Forms.Padding(2);
            this.txtEmailEditarCadastro.Name = "txtEmailEditarCadastro";
            this.txtEmailEditarCadastro.Size = new System.Drawing.Size(352, 24);
            this.txtEmailEditarCadastro.TabIndex = 6;
            // 
            // maskCPFEditarCadastro
            // 
            this.maskCPFEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.maskCPFEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskCPFEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.maskCPFEditarCadastro.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.maskCPFEditarCadastro.Location = new System.Drawing.Point(65, 200);
            this.maskCPFEditarCadastro.Mask = "000 , 000 , 000 - 00 ";
            this.maskCPFEditarCadastro.Name = "maskCPFEditarCadastro";
            this.maskCPFEditarCadastro.Size = new System.Drawing.Size(350, 24);
            this.maskCPFEditarCadastro.TabIndex = 2;
            // 
            // maskDataNascimentoEditar
            // 
            this.maskDataNascimentoEditar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.maskDataNascimentoEditar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskDataNascimentoEditar.ForeColor = System.Drawing.Color.DimGray;
            this.maskDataNascimentoEditar.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.maskDataNascimentoEditar.Location = new System.Drawing.Point(65, 264);
            this.maskDataNascimentoEditar.Mask = "00 / 00 / 0000";
            this.maskDataNascimentoEditar.Name = "maskDataNascimentoEditar";
            this.maskDataNascimentoEditar.Size = new System.Drawing.Size(350, 24);
            this.maskDataNascimentoEditar.TabIndex = 3;
            this.maskDataNascimentoEditar.ValidatingType = typeof(System.DateTime);
            // 
            // maskTelefoneEditarCadastro
            // 
            this.maskTelefoneEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.maskTelefoneEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskTelefoneEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.maskTelefoneEditarCadastro.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.maskTelefoneEditarCadastro.Location = new System.Drawing.Point(65, 328);
            this.maskTelefoneEditarCadastro.Mask = "( 00 ) 00000 - 0000";
            this.maskTelefoneEditarCadastro.Name = "maskTelefoneEditarCadastro";
            this.maskTelefoneEditarCadastro.Size = new System.Drawing.Size(350, 24);
            this.maskTelefoneEditarCadastro.TabIndex = 4;
            // 
            // maskValidadeCNHEditarCadastro
            // 
            this.maskValidadeCNHEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.maskValidadeCNHEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskValidadeCNHEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.maskValidadeCNHEditarCadastro.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.maskValidadeCNHEditarCadastro.Location = new System.Drawing.Point(483, 328);
            this.maskValidadeCNHEditarCadastro.Mask = "00/00/0000";
            this.maskValidadeCNHEditarCadastro.Name = "maskValidadeCNHEditarCadastro";
            this.maskValidadeCNHEditarCadastro.Size = new System.Drawing.Size(350, 24);
            this.maskValidadeCNHEditarCadastro.TabIndex = 9;
            this.maskValidadeCNHEditarCadastro.ValidatingType = typeof(System.DateTime);
            this.maskValidadeCNHEditarCadastro.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskValidadeCNHEditarCadastro_MaskInputRejected);
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula.ForeColor = System.Drawing.Color.DimGray;
            this.lblMatricula.Location = new System.Drawing.Point(62, 37);
            this.lblMatricula.Margin = new System.Windows.Forms.Padding(0);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(356, 32);
            this.lblMatricula.TabIndex = 33;
            this.lblMatricula.Text = "Matrícula *";
            this.lblMatricula.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.ForeColor = System.Drawing.Color.DimGray;
            this.lblNome.Location = new System.Drawing.Point(62, 101);
            this.lblNome.Margin = new System.Windows.Forms.Padding(0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(356, 32);
            this.lblNome.TabIndex = 34;
            this.lblNome.Text = "Nome *";
            this.lblNome.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblCpf
            // 
            this.lblCpf.AutoSize = true;
            this.lblCpf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCpf.ForeColor = System.Drawing.Color.DimGray;
            this.lblCpf.Location = new System.Drawing.Point(62, 165);
            this.lblCpf.Margin = new System.Windows.Forms.Padding(0);
            this.lblCpf.Name = "lblCpf";
            this.lblCpf.Size = new System.Drawing.Size(356, 32);
            this.lblCpf.TabIndex = 35;
            this.lblCpf.Text = "CPF *";
            this.lblCpf.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblDataDeNascimento
            // 
            this.lblDataDeNascimento.AutoSize = true;
            this.lblDataDeNascimento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDataDeNascimento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataDeNascimento.ForeColor = System.Drawing.Color.DimGray;
            this.lblDataDeNascimento.Location = new System.Drawing.Point(62, 229);
            this.lblDataDeNascimento.Margin = new System.Windows.Forms.Padding(0);
            this.lblDataDeNascimento.Name = "lblDataDeNascimento";
            this.lblDataDeNascimento.Size = new System.Drawing.Size(356, 32);
            this.lblDataDeNascimento.TabIndex = 36;
            this.lblDataDeNascimento.Text = "Data de Nascimento *";
            this.lblDataDeNascimento.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblTelefone
            // 
            this.lblTelefone.AutoSize = true;
            this.lblTelefone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTelefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefone.ForeColor = System.Drawing.Color.DimGray;
            this.lblTelefone.Location = new System.Drawing.Point(62, 293);
            this.lblTelefone.Margin = new System.Windows.Forms.Padding(0);
            this.lblTelefone.Name = "lblTelefone";
            this.lblTelefone.Size = new System.Drawing.Size(356, 32);
            this.lblTelefone.TabIndex = 37;
            this.lblTelefone.Text = "Celular *";
            this.lblTelefone.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCargo.ForeColor = System.Drawing.Color.DimGray;
            this.lblCargo.Location = new System.Drawing.Point(480, 37);
            this.lblCargo.Margin = new System.Windows.Forms.Padding(0);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(356, 32);
            this.lblCargo.TabIndex = 38;
            this.lblCargo.Text = "Cargo *";
            this.lblCargo.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.ForeColor = System.Drawing.Color.DimGray;
            this.lblEmail.Location = new System.Drawing.Point(480, 101);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(356, 32);
            this.lblEmail.TabIndex = 39;
            this.lblEmail.Text = "E-mail *";
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblNumeroCnh
            // 
            this.lblNumeroCnh.AutoSize = true;
            this.lblNumeroCnh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNumeroCnh.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroCnh.ForeColor = System.Drawing.Color.DimGray;
            this.lblNumeroCnh.Location = new System.Drawing.Point(480, 165);
            this.lblNumeroCnh.Margin = new System.Windows.Forms.Padding(0);
            this.lblNumeroCnh.Name = "lblNumeroCnh";
            this.lblNumeroCnh.Size = new System.Drawing.Size(356, 32);
            this.lblNumeroCnh.TabIndex = 40;
            this.lblNumeroCnh.Text = "Número da CNH";
            this.lblNumeroCnh.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblCategoriaDaCnh
            // 
            this.lblCategoriaDaCnh.AutoSize = true;
            this.lblCategoriaDaCnh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCategoriaDaCnh.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoriaDaCnh.ForeColor = System.Drawing.Color.DimGray;
            this.lblCategoriaDaCnh.Location = new System.Drawing.Point(480, 229);
            this.lblCategoriaDaCnh.Margin = new System.Windows.Forms.Padding(0);
            this.lblCategoriaDaCnh.Name = "lblCategoriaDaCnh";
            this.lblCategoriaDaCnh.Size = new System.Drawing.Size(356, 32);
            this.lblCategoriaDaCnh.TabIndex = 41;
            this.lblCategoriaDaCnh.Text = "Categoria da CNH";
            this.lblCategoriaDaCnh.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblValidadeCnh
            // 
            this.lblValidadeCnh.AutoSize = true;
            this.lblValidadeCnh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblValidadeCnh.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidadeCnh.ForeColor = System.Drawing.Color.DimGray;
            this.lblValidadeCnh.Location = new System.Drawing.Point(480, 293);
            this.lblValidadeCnh.Margin = new System.Windows.Forms.Padding(0);
            this.lblValidadeCnh.Name = "lblValidadeCnh";
            this.lblValidadeCnh.Size = new System.Drawing.Size(356, 32);
            this.lblValidadeCnh.TabIndex = 42;
            this.lblValidadeCnh.Text = "Validade da CNH";
            this.lblValidadeCnh.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // btnEditarCadastroFuncionario
            // 
            this.btnEditarCadastroFuncionario.BackColor = System.Drawing.Color.Gray;
            this.btnEditarCadastroFuncionario.FlatAppearance.BorderSize = 0;
            this.btnEditarCadastroFuncionario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btnEditarCadastroFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditarCadastroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditarCadastroFuncionario.ForeColor = System.Drawing.Color.White;
            this.btnEditarCadastroFuncionario.Image = global::PimForms.Properties.Resources.icone_confirmar_20x20;
            this.btnEditarCadastroFuncionario.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEditarCadastroFuncionario.Location = new System.Drawing.Point(480, 396);
            this.btnEditarCadastroFuncionario.Margin = new System.Windows.Forms.Padding(0);
            this.btnEditarCadastroFuncionario.Name = "btnEditarCadastroFuncionario";
            this.btnEditarCadastroFuncionario.Size = new System.Drawing.Size(110, 30);
            this.btnEditarCadastroFuncionario.TabIndex = 11;
            this.btnEditarCadastroFuncionario.Text = "    Salvar";
            this.btnEditarCadastroFuncionario.UseVisualStyleBackColor = false;
            this.btnEditarCadastroFuncionario.Click += new System.EventHandler(this.BtnEditarCadastroFuncionario_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.Gray;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = global::PimForms.Properties.Resources.icone_cancelar_20x20;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(308, 396);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 30);
            this.button1.TabIndex = 12;
            this.button1.Text = "     Fechar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.BtnCancelarEditarCadastroFuncionario_Click);
            // 
            // labeltesteErro
            // 
            this.labeltesteErro.AutoSize = true;
            this.labeltesteErro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labeltesteErro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltesteErro.ForeColor = System.Drawing.Color.Red;
            this.labeltesteErro.Location = new System.Drawing.Point(65, 357);
            this.labeltesteErro.Name = "labeltesteErro";
            this.labeltesteErro.Size = new System.Drawing.Size(350, 39);
            this.labeltesteErro.TabIndex = 44;
            this.labeltesteErro.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBoxCategoriaCnhEditar
            // 
            this.comboBoxCategoriaCnhEditar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxCategoriaCnhEditar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCategoriaCnhEditar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxCategoriaCnhEditar.ForeColor = System.Drawing.Color.DimGray;
            this.comboBoxCategoriaCnhEditar.FormattingEnabled = true;
            this.comboBoxCategoriaCnhEditar.Items.AddRange(new object[] {
            "A",
            "B",
            "AB",
            "C",
            "D",
            "E"});
            this.comboBoxCategoriaCnhEditar.Location = new System.Drawing.Point(483, 264);
            this.comboBoxCategoriaCnhEditar.Name = "comboBoxCategoriaCnhEditar";
            this.comboBoxCategoriaCnhEditar.Size = new System.Drawing.Size(350, 23);
            this.comboBoxCategoriaCnhEditar.TabIndex = 45;
            // 
            // lblMesagemObrigatoriedade
            // 
            this.lblMesagemObrigatoriedade.AutoSize = true;
            this.lblMesagemObrigatoriedade.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMesagemObrigatoriedade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMesagemObrigatoriedade.ForeColor = System.Drawing.Color.DimGray;
            this.lblMesagemObrigatoriedade.Location = new System.Drawing.Point(65, 0);
            this.lblMesagemObrigatoriedade.Name = "lblMesagemObrigatoriedade";
            this.lblMesagemObrigatoriedade.Size = new System.Drawing.Size(350, 37);
            this.lblMesagemObrigatoriedade.TabIndex = 46;
            this.lblMesagemObrigatoriedade.Text = "(*)  Campos de preenchimento Obrigatório";
            this.lblMesagemObrigatoriedade.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.931329F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.55844F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.941231F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.63768F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.931329F));
            this.tableLayoutPanel1.Controls.Add(this.txtMatriculaEditarCadastro, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtNomeEditarCadastro, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtNumeroCNHEditar, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtCargoEditarCadastro, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtEmailEditarCadastro, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.maskCPFEditarCadastro, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.maskDataNascimentoEditar, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.maskTelefoneEditarCadastro, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.maskValidadeCNHEditarCadastro, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.lblMatricula, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblNome, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblCpf, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblDataDeNascimento, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblTelefone, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.lblCargo, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblEmail, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblNumeroCnh, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblCategoriaDaCnh, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblValidadeCnh, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.btnEditarCadastroFuncionario, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.button1, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.labeltesteErro, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.comboBoxCategoriaCnhEditar, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.lblMesagemObrigatoriedade, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 32);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.083411F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.005459F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.360761F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.50123F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(900, 468);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // lblTituloForm
            // 
            this.lblTituloForm.BackColor = System.Drawing.Color.Gray;
            this.lblTituloForm.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTituloForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloForm.ForeColor = System.Drawing.Color.White;
            this.lblTituloForm.Location = new System.Drawing.Point(0, 0);
            this.lblTituloForm.Margin = new System.Windows.Forms.Padding(0);
            this.lblTituloForm.Name = "lblTituloForm";
            this.lblTituloForm.Size = new System.Drawing.Size(900, 32);
            this.lblTituloForm.TabIndex = 3;
            this.lblTituloForm.Text = "Editar Funcionário";
            this.lblTituloForm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EditarCadastroFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(900, 500);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.lblTituloForm);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EditarCadastroFuncionario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditarCadastroFuncionario";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.EditarCadastroFuncionario_MouseDown);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblCpf;
        private System.Windows.Forms.Label lblDataDeNascimento;
        private System.Windows.Forms.Label lblTelefone;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblNumeroCnh;
        private System.Windows.Forms.Label lblCategoriaDaCnh;
        private System.Windows.Forms.Label lblValidadeCnh;
        private System.Windows.Forms.Button btnEditarCadastroFuncionario;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label labeltesteErro;
        private System.Windows.Forms.Label lblMesagemObrigatoriedade;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        public System.Windows.Forms.Label lblTituloForm;
        public System.Windows.Forms.TextBox txtMatriculaEditarCadastro;
        public System.Windows.Forms.TextBox txtNomeEditarCadastro;
        public System.Windows.Forms.TextBox txtNumeroCNHEditar;
        public System.Windows.Forms.TextBox txtCargoEditarCadastro;
        public System.Windows.Forms.TextBox txtEmailEditarCadastro;
        public System.Windows.Forms.MaskedTextBox maskCPFEditarCadastro;
        public System.Windows.Forms.MaskedTextBox maskDataNascimentoEditar;
        public System.Windows.Forms.MaskedTextBox maskTelefoneEditarCadastro;
        public System.Windows.Forms.MaskedTextBox maskValidadeCNHEditarCadastro;
        public System.Windows.Forms.ComboBox comboBoxCategoriaCnhEditar;
    }
}