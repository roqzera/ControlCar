﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PimForms.Classes;
using PimForms.Dao;
using PimForms.Formulários;

namespace PimForms.Formulários
{
    public partial class ListarViagem : Form
    {
        public ListarViagem()
        {
            InitializeComponent();
            Listar();
        }

        
        public void Pesquisar()
        {
            

            //FuncionarioDao funcionarios = new FuncionarioDao();
            //dataGridListar.DataSource = funcionarios.BuscarFuncionario(matricula);
        }
        

        public void Listar()
        {
            ViagemDao viagemDao = new ViagemDao();
            //strMysql armazena o retorno do método BuscarFuncionario(), que é uma string de comando MySql. 
            string strMysql = viagemDao.ListarViagens();
            // A string strMysql é passada por parâmetro para que o método ExibirNoDataGridView() possa fazer a conexão com o banco e exibir os dados buscados no DataGridView
            dataGridListar.DataSource = viagemDao.ExibirNoDataGridView(strMysql);
            //dataGridListar.Columns["id_funcionario"].Visible = false;
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            Listar();
        }

        private void ToolStripButtonPesquisar_Click(object sender, EventArgs e)
        {
            FuncionarioDao funcionarioDao = new FuncionarioDao();
            int idFuncionario = Convert.ToInt32(funcionarioDao.BuscarIdFuncionario("matricula", toolStripTextBoxMatricula.Text));

            VeiculoDao veiculoDao = new VeiculoDao();
            int idVeiculo = Convert.ToInt32(veiculoDao.BuscarIdVeiculo(toolStripTextBoxPlaca.Text));

            ViagemDao viagemDao = new ViagemDao();
            string strMysql = viagemDao.PesquisarViagem(idFuncionario, idVeiculo);

            // A string strMysql é passada por parâmetro para que o método ExibirNoDataGridView() possa fazer a conexão com o banco e exibir os dados buscados no DataGridView
            dataGridListar.DataSource = viagemDao.ExibirNoDataGridView(strMysql);
            //dataGridListar.Columns["id_funcionario"].Visible = false;
        }

        private void ToolStripButtonListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        private void ToolStripButtonEditar_Click(object sender, EventArgs e)
        {
            EditarCadastroViagem editarCadastroViagem = new EditarCadastroViagem();

            if (dataGridListar.SelectedRows.Count > 0)
            {
                //ViagemDao viagemDao = new ViagemDao();
                editarCadastroViagem.txtEditarPlaca.Text = dataGridListar.CurrentRow.Cells["placa"].Value.ToString();
                editarCadastroViagem.txtEditarFuncionario.Text = dataGridListar.CurrentRow.Cells["nome"].Value.ToString();
                editarCadastroViagem.txtEditarDestino.Text = dataGridListar.CurrentRow.Cells["destino"].Value.ToString();
                editarCadastroViagem.maskEditarValorAdiantamento.Text = dataGridListar.CurrentRow.Cells["valor_adiantamento"].Value.ToString();
                editarCadastroViagem.maskedEditarDataSaida.Text = dataGridListar.CurrentRow.Cells["data_saida"].Value.ToString();
                editarCadastroViagem.maskedEditarDataRetorno.Text = dataGridListar.CurrentRow.Cells["data_retorno"].Value.ToString();
                editarCadastroViagem.txtEditarKmInicial.Text = dataGridListar.CurrentRow.Cells["km_inicial"].Value.ToString();
                editarCadastroViagem.txtEditarKmFinal.Text = dataGridListar.CurrentRow.Cells["km_final"].Value.ToString();
                editarCadastroViagem.txtEditarAcompanhante1.Text = dataGridListar.CurrentRow.Cells["acompanhante1"].Value.ToString();
                editarCadastroViagem.txtEditarAcompanhante2.Text = dataGridListar.CurrentRow.Cells["acompanhante2"].Value.ToString();
                editarCadastroViagem.txtEditarAcompanhante3.Text = dataGridListar.CurrentRow.Cells["acompanhante3"].Value.ToString();
                editarCadastroViagem.lblId.Text = dataGridListar.CurrentRow.Cells["id_viagem"].Value.ToString();
            }

            editarCadastroViagem.Show();
        }
    }
}
