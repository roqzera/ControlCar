﻿using MySql.Data.MySqlClient;
using PimForms.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PimForms.Dao
{
    class ViagemDao
    {
        MySqlCommand cmd = new MySqlCommand();
        ConexaoBanco conexao = new ConexaoBanco();
        MySqlConnection mySqlConnection;
        FuncionarioDao funcionarioDao = new FuncionarioDao();

        private string strConn = @"server=localhost;database=controlcar;userid=ja_server;password=ja23;";

        public void AdicionarViagem(Viagem viagem, string idAcompanhante)
        {
            //Comando Sql: insert, update, delete

            cmd.CommandText = "INSERT INTO viagem (data_saida, data_retorno, destino, valor_adiantamento, km_inicial, km_final, id_veiculo, id_funcionario, id_acompanhante) " +
                "VALUES (@DataSaida, @DataRetorno, @Destino, @ValorAdiantamento, @KmInicial, @KmFinal, @IdVeiculo, @IdFuncionario, @IdAcompanhante)";

            //Parametros
            cmd.Parameters.AddWithValue("@DataSaida", viagem.DataSaida);
            cmd.Parameters.AddWithValue("@DataRetorno", viagem.DataRetorno);
            cmd.Parameters.AddWithValue("@Destino", viagem.Destino);
            cmd.Parameters.AddWithValue("@ValorAdiantamento", viagem.ValorAdiantamento);
            cmd.Parameters.AddWithValue("@KmInicial", viagem.KmInicial);
            cmd.Parameters.AddWithValue("@KmFinal", viagem.KmFinal);
            cmd.Parameters.AddWithValue("@IdVeiculo", viagem.IdVeiculo);
            cmd.Parameters.AddWithValue("@IdFuncionario", viagem.IdFuncionario);
            cmd.Parameters.AddWithValue("@IdAcompanhante", idAcompanhante);

            try
            {
                //Conectar com o banco
                cmd.Connection = conexao.Conectar();
                //Executar Comando
                cmd.ExecuteNonQuery();
                //Desconectar
                conexao.Desconectar();
                //Mostrar mensagem de sucesso/erro
                MessageBox.Show("Cadastro realizado com sucesso!");
            }

            catch (MySqlException)
            {
                //MessageBox.Show("Erro ao tentar se conectar com o banco de dados");
                //throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }

        /*
        public List<Viagem> ListarViagem()
        {
            List<Viagem> viagens = new List<Viagem>();
            MySqlConnection conn = new MySqlConnection(strConn); //comando para obter o número de linhas                                                                                                                               //existentes no BD      
            string sql1 = "select v.id_funcionario, v.id_veiculo, v.data_saida, v.data_retorno, v.destino, v.valor_adiantamento, v.km_inicial, v.km_final, v.acompanhante1, v.acompanhante2, v.acompanhante3, f.nome as motorista, veic.Placa, a.acompanhante1, a.acompanhante2, a.acompanhante3 from viagem v inner join funcionario f on v.id_funcionario = f.id_funcionario inner join veiculo veic on v.id_veiculo = veic.id_veiculo inner join acompanhante a on v.id_acompanhante = a.id_acompanhante;";
            MySqlCommand cmd1 = new MySqlCommand(sql1.ToString(), conn);
            conn.Open();
            MySqlDataReader rdr = cmd1.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Viagem v = new Viagem()
                    {
                        DataSaida = Convert.ToDateTime(rdr["v.data_saida"]),
                        DataRetorno = Convert.ToDateTime(rdr["v.data_retorno"]),
                        Destino = Convert.ToString(rdr["v.destino"]),
                        ValorAdiantamento = Convert.ToDecimal(rdr["v.valor_adiantamento"]),
                        KmInicial = Convert.ToDecimal(rdr["v.km_inicial"]),
                        KmFinal = Convert.ToDecimal(rdr["v.km_final"]),
                        IdFuncionario = Convert.ToInt32(rdr["v.id_funcionario"]),
                        IdVeiculo = Convert.ToInt32(rdr["v.id_veiculo"]),
                        Acompanhante1 = Convert.ToString(rdr["v.acompanhante1"]),
                        Acompanhante2 = Convert.ToString(rdr["v.acompanhante2"]),
                        Acompanhante3 = Convert.ToString(rdr["v.acompanhante3"]),
                    };

                    viagens.Add(v);
                }
            }
            conn.Close();
            return viagens;
        }
        */

        public string ListarViagens()
        {
            string strMysql = "select id_viagem, f.nome, veic.Placa, v.data_saida, v.data_retorno, v.destino, v.valor_adiantamento, v.km_inicial, v.km_final, a.acompanhante1, a.acompanhante2, a.acompanhante3 from viagem v inner join funcionario f on v.id_funcionario = f.id_funcionario inner join veiculo veic on v.id_veiculo = veic.id_veiculo inner join acompanhante a on v.id_acompanhante = a.id_acompanhante;";
       
            return strMysql;
        }

        public DataTable ExibirNoDataGridView(string strCon)
        {
            try
            {
                mySqlConnection = conexao.Conectar();
                cmd = new MySqlCommand(strCon, mySqlConnection);

                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter();
                // Seleciona os dados do banco e preenche o DataAdapter com esses dados
                mySqlDataAdapter.SelectCommand = cmd;

                DataTable dataTable = new DataTable();
                // Armazena no DataTable os dados que foram buscados no banco com o uso do SelectCommand
                mySqlDataAdapter.Fill(dataTable);

                return dataTable;
            }

            catch (MySqlException ex)
            {
                throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }

        public string PesquisarViagem(int idFuncionario, int idVeiculo)
        {

            string strMysql = "SELECT vi.* FROM veiculo v, viagem vi, funcionario f WHERE v.id_veiculo = vi.id_veiculo and f.id_funcionario = vi.id_funcionario and f.id_funcionario = '" + idFuncionario + "' AND v.id_veiculo = '" + idVeiculo + "';";
            //cmd.Parameters.AddWithValue("@placa", placa);

            return strMysql;
        }

        public string FiltrarViagemVeiculo(string placa)
        {

            string strMysql = "SELECT * FROM veiculo_viagem WHERE placa = '"+placa+"';";
            //cmd.Parameters.AddWithValue("@placa", placa);

            return strMysql;
        }

        public string FiltrarViagemFuncionario(string matricula)
        {

            string strMysql = "SELECT * FROM funcionario_viagem WHERE matricula = '"+matricula+"';";
            //cmd.Parameters.AddWithValue("@matricula", matricula);

            return strMysql;
        }

        public string EditarViagem(Viagem viagem, int id)
        {

            cmd.CommandText = "UPDATE viagem SET data_saida=@data_saida, data_retorno=@data_retorno, destino=@destino, valor_adiantamento=@valor_adiantamento, km_inicial=@km_inicial, km_final=@km_final, id_funcionario=@id_funcionario, id_veiculo=@id_veiculo WHERE id_viagem=@id_viagem";

            cmd.Parameters.AddWithValue("@data_saida", viagem.DataSaida);
            cmd.Parameters.AddWithValue("@data_retorno", viagem.DataRetorno);
            cmd.Parameters.AddWithValue("@destino", viagem.Destino);
            cmd.Parameters.AddWithValue("@valor_adiantamento", viagem.ValorAdiantamento);
            cmd.Parameters.AddWithValue("@km_inicial", viagem.KmInicial);
            cmd.Parameters.AddWithValue("@km_final", viagem.KmFinal);
            cmd.Parameters.AddWithValue("@id_funcionario", viagem.IdFuncionario);
            cmd.Parameters.AddWithValue("@id_veiculo", viagem.IdVeiculo);
            cmd.Parameters.AddWithValue("@id_viagem", id);

            try
            {
                cmd.Connection = conexao.Conectar();
                cmd.ExecuteNonQuery();
                conexao.Desconectar();
                MessageBox.Show("Cadastro atualizado com sucesso!");
                return null;
            }

            catch (MySqlException ex)
            {
                return Convert.ToString(ex);
                MessageBox.Show("Erro ao tentar se conectar com o banco de dados");
                throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }
    }
}
