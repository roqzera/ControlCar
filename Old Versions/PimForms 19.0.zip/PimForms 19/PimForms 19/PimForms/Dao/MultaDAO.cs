﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;

namespace PimForms.Classes
{
    public class MultaDAO
    {

        MySqlCommand cmd = new MySqlCommand();
        ConexaoBanco conexao = new ConexaoBanco();
        MySqlConnection mySqlConnection = new MySqlConnection();

        private string strConn = @"server=localhost;database=controlcar;userid=ja_server;password=ja23;";

        public void AdcionarMulta(Multa multa)
        {
            cmd.CommandText = "INSERT INTO multa (numero_infracao, data_multa, valor, id_funcionario, id_veiculo) VALUES (@numDaInfracao, @datamulta, @valor, @id_funcionario, @id_veiculo)";
            cmd.Parameters.AddWithValue("@numDaInfracao", multa.NumeroDaInfracao);
            cmd.Parameters.AddWithValue("@datamulta", multa.Data);
            cmd.Parameters.AddWithValue("@valor", multa.Valor);
            cmd.Parameters.AddWithValue("@id_funcionario", multa.Funcionario);
            cmd.Parameters.AddWithValue("@id_veiculo", multa.Veiculo);

            try
            {
                cmd.Connection = conexao.Conectar();
                cmd.ExecuteNonQuery();
                conexao.Desconectar();
                MessageBox.Show("CADASTRADO COM SUCESSO");
            }
            catch (MySqlException)
            {
                MessageBox.Show("ERRO COM O BANCO DE DADOS");
            }

        }

        public void ExcluirMulta(string id_multa)
        {
            cmd.CommandText = "DELETE FROM multa2 WHERE id_multa =" + id_multa;

            try
            {
                cmd.Connection = conexao.Conectar();
                cmd.ExecuteNonQuery();
                conexao.Desconectar();
            }

            catch (MySqlException ex)
            {
                MessageBox.Show("Erro ao tentar se conectar com o banco de dados");
                throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }





        public void EditarMulta(string numeroDaInfracao, string placa, decimal valor, DateTime data, string id_multa)
        {

            cmd.CommandText = "UPDATE multa SET numero_infracao=@numeroDaInfracao, placa=@placa, valor=@valor, data_multa=@dataMulta WHERE id_multa = @id_multa;";

            cmd.Parameters.AddWithValue("@id_multa", id_multa);
            cmd.Parameters.AddWithValue("@numeroDaInfracao", numeroDaInfracao);
            cmd.Parameters.AddWithValue("@placa", placa);
            cmd.Parameters.AddWithValue("@valor", valor);
            cmd.Parameters.AddWithValue("@dataMulta", data);

            try
            {
                cmd.Connection = conexao.Conectar();
                cmd.ExecuteNonQuery();
                conexao.Desconectar();
                MessageBox.Show("Cadastro atualizado com sucesso!");
            }

            catch (Exception)
            {
                MessageBox.Show("Erro ao tentar se conectar com o banco de dados");

            }

            finally
            {
                conexao.Desconectar();
            }
        }

        public DataTable ExibirNoDataGridView(string strCon)
        {
            try
            {
                mySqlConnection = conexao.Conectar();
                cmd = new MySqlCommand(strCon, mySqlConnection);

                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter();
                // Seleciona os dados do banco e preenche o DataAdapter com esses dados
                mySqlDataAdapter.SelectCommand = cmd;

                DataTable dataTable = new DataTable();
                // Armazena no DataTable os dados que foram buscados no banco com o uso do SelectCommand
                mySqlDataAdapter.Fill(dataTable);

                return dataTable;
            }

            catch (MySqlException ex)
            {
                throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }


        }

        public List<Multa> BuscarMultaLista(string placa)
        {
            List<Multa> multas = new List<Multa>();
            MySqlConnection conn = new MySqlConnection(strConn);
            string strMysql = "SELECT * FROM multa WHERE placa ='" + placa + "';";
            MySqlCommand cmd1 = new MySqlCommand(strMysql.ToString(), conn);
            conn.Open();
            MySqlDataReader rdr = cmd1.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Multa m = new Multa()
                    {
                        
                        //Placa = Convert.ToString(rdr["placa"]),
                        NumeroDaInfracao = Convert.ToString(rdr["numero_infracao"]),
                        Valor = Convert.ToDecimal(rdr["valor"]),
                        Data = Convert.ToDateTime(rdr["data_multa"])
                    };
                    multas.Add(m);
                }
            }
            conn.Close();
            return multas;
        }
        public List<Multa> ListarMultas()
        {
            List<Multa> multa = new List<Multa>();
            MySqlConnection conn = new MySqlConnection(strConn);
            string sql1 = "SELECT multa.id_multa, multa.numero_infracao, multa.valor, multa.data_multa, funcionario.nome, veiculo.placa FROM multa INNER JOIN funcionario ON ( multa.id_funcionario = funcionario.id_funcionario) INNER JOIN veiculo ON (multa.id_veiculo = veiculo.id_veiculo);";
            MySqlCommand cmd1 = new MySqlCommand(sql1.ToString(), conn);
            conn.Open();
            MySqlDataReader rdr = cmd1.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Multa m = new Multa()
                    {
                        //Placa = Convert.ToString(rdr["placa"]),
                        NumeroDaInfracao = Convert.ToString(rdr["numero_infracao"]),
                        Valor = Convert.ToDecimal(rdr["valor"]),
                        Data = Convert.ToDateTime(rdr["data_multa"]),
                        Funcionario = Convert.ToInt16(rdr["id_funcionario"])
                    };

                    multa.Add(m);
                }
            }
            conn.Close();
            return multa;
        }

        public string BuscarIdMulta(string valor)
        {
            try
            {
                string strMysql = "SELECT id_multa FROM multa WHERE placa ='" + valor + "';";
                mySqlConnection = conexao.Conectar();
                cmd = new MySqlCommand(strMysql, mySqlConnection);

                // Seleciona os dados do banco e preenche o DataAdapter com esses dados
                var result = cmd.ExecuteScalar();


                // Armazena no DataTable os dados que foram buscados no banco com o uso do SelectCommand
                string id = Convert.ToString(result);

                return id;
            }

            catch (MySqlException ex)
            {
                throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }


        public string ListarMulta()
        {
            string strMysql = "SELECT multa.id_multa, multa.numero_infracao, multa.valor, multa.data_multa, funcionario.nome, veiculo.placa FROM multa INNER JOIN funcionario ON(multa.id_funcionario = funcionario.id_funcionario) INNER JOIN veiculo ON(multa.id_veiculo = veiculo.id_veiculo);";

            return strMysql;
        }

    }
}

