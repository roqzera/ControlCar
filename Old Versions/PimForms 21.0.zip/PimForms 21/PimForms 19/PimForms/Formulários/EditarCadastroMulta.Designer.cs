﻿namespace PimForms.Formulários
{
    partial class EditarCadastroMulta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.labeltesteErro = new System.Windows.Forms.Label();
            this.lblMesagemObrigatoriedade = new System.Windows.Forms.Label();
            this.lblFuncionario = new System.Windows.Forms.Label();
            this.lblPlaca = new System.Windows.Forms.Label();
            this.lblNumeroDaInfracao = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.lblValor = new System.Windows.Forms.Label();
            this.maskData = new System.Windows.Forms.MaskedTextBox();
            this.MaskNumInfracao = new System.Windows.Forms.MaskedTextBox();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.tbxFuncionario = new System.Windows.Forms.TextBox();
            this.lblId = new System.Windows.Forms.Label();
            this.maskedPlaca = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.931329F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.55844F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.941231F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.63768F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.931329F));
            this.tableLayoutPanel1.Controls.Add(this.btnSalvar, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.btnFechar, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.labeltesteErro, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.lblMesagemObrigatoriedade, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblFuncionario, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblPlaca, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblNumeroDaInfracao, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblData, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblValor, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.maskData, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.MaskNumInfracao, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtValor, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.tbxFuncionario, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblId, 4, 11);
            this.tableLayoutPanel1.Controls.Add(this.maskedPlaca, 1, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 31);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 15;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.083411F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.005459F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.360761F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.50123F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(900, 453);
            this.tableLayoutPanel1.TabIndex = 8;
            // 
            // btnSalvar
            // 
            this.btnSalvar.BackColor = System.Drawing.Color.Gray;
            this.btnSalvar.FlatAppearance.BorderSize = 0;
            this.btnSalvar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvar.ForeColor = System.Drawing.Color.White;
            this.btnSalvar.Image = global::PimForms.Properties.Resources.icone_confirmar_20x20;
            this.btnSalvar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalvar.Location = new System.Drawing.Point(480, 347);
            this.btnSalvar.Margin = new System.Windows.Forms.Padding(0);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(110, 30);
            this.btnSalvar.TabIndex = 8;
            this.btnSalvar.Text = "     Salvar";
            this.btnSalvar.UseVisualStyleBackColor = false;
            this.btnSalvar.Click += new System.EventHandler(this.BtnSalvar_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFechar.BackColor = System.Drawing.Color.Gray;
            this.btnFechar.FlatAppearance.BorderSize = 0;
            this.btnFechar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btnFechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFechar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFechar.ForeColor = System.Drawing.Color.White;
            this.btnFechar.Image = global::PimForms.Properties.Resources.icone_cancelar_20x20;
            this.btnFechar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFechar.Location = new System.Drawing.Point(308, 347);
            this.btnFechar.Margin = new System.Windows.Forms.Padding(0);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(110, 30);
            this.btnFechar.TabIndex = 9;
            this.btnFechar.Text = "      Fechar";
            this.btnFechar.UseVisualStyleBackColor = false;
            this.btnFechar.Click += new System.EventHandler(this.BtnFechar_Click);
            // 
            // labeltesteErro
            // 
            this.labeltesteErro.AutoSize = true;
            this.labeltesteErro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labeltesteErro.ForeColor = System.Drawing.Color.Red;
            this.labeltesteErro.Location = new System.Drawing.Point(65, 313);
            this.labeltesteErro.Name = "labeltesteErro";
            this.labeltesteErro.Size = new System.Drawing.Size(350, 34);
            this.labeltesteErro.TabIndex = 44;
            this.labeltesteErro.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblMesagemObrigatoriedade
            // 
            this.lblMesagemObrigatoriedade.AutoSize = true;
            this.lblMesagemObrigatoriedade.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMesagemObrigatoriedade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMesagemObrigatoriedade.ForeColor = System.Drawing.Color.DimGray;
            this.lblMesagemObrigatoriedade.Location = new System.Drawing.Point(65, 0);
            this.lblMesagemObrigatoriedade.Name = "lblMesagemObrigatoriedade";
            this.lblMesagemObrigatoriedade.Size = new System.Drawing.Size(350, 33);
            this.lblMesagemObrigatoriedade.TabIndex = 47;
            this.lblMesagemObrigatoriedade.Text = "(*)  Campos de preenchimento Obrigatório";
            this.lblMesagemObrigatoriedade.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblFuncionario
            // 
            this.lblFuncionario.AutoSize = true;
            this.lblFuncionario.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.lblFuncionario.ForeColor = System.Drawing.Color.DimGray;
            this.lblFuncionario.Location = new System.Drawing.Point(62, 33);
            this.lblFuncionario.Margin = new System.Windows.Forms.Padding(0);
            this.lblFuncionario.Name = "lblFuncionario";
            this.lblFuncionario.Size = new System.Drawing.Size(356, 28);
            this.lblFuncionario.TabIndex = 60;
            this.lblFuncionario.Text = "Nome do Funcionário *";
            this.lblFuncionario.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblPlaca
            // 
            this.lblPlaca.AutoSize = true;
            this.lblPlaca.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPlaca.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.lblPlaca.ForeColor = System.Drawing.Color.DimGray;
            this.lblPlaca.Location = new System.Drawing.Point(62, 89);
            this.lblPlaca.Margin = new System.Windows.Forms.Padding(0);
            this.lblPlaca.Name = "lblPlaca";
            this.lblPlaca.Size = new System.Drawing.Size(356, 28);
            this.lblPlaca.TabIndex = 59;
            this.lblPlaca.Text = "Placa do Veículo *";
            this.lblPlaca.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblNumeroDaInfracao
            // 
            this.lblNumeroDaInfracao.AutoSize = true;
            this.lblNumeroDaInfracao.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNumeroDaInfracao.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.lblNumeroDaInfracao.ForeColor = System.Drawing.Color.DimGray;
            this.lblNumeroDaInfracao.Location = new System.Drawing.Point(62, 145);
            this.lblNumeroDaInfracao.Margin = new System.Windows.Forms.Padding(0);
            this.lblNumeroDaInfracao.Name = "lblNumeroDaInfracao";
            this.lblNumeroDaInfracao.Size = new System.Drawing.Size(356, 28);
            this.lblNumeroDaInfracao.TabIndex = 56;
            this.lblNumeroDaInfracao.Text = "Numero da Infração *";
            this.lblNumeroDaInfracao.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblData.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.lblData.ForeColor = System.Drawing.Color.DimGray;
            this.lblData.Location = new System.Drawing.Point(62, 201);
            this.lblData.Margin = new System.Windows.Forms.Padding(0);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(356, 28);
            this.lblData.TabIndex = 58;
            this.lblData.Text = "Data *";
            this.lblData.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.lblValor.ForeColor = System.Drawing.Color.DimGray;
            this.lblValor.Location = new System.Drawing.Point(62, 257);
            this.lblValor.Margin = new System.Windows.Forms.Padding(0);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(356, 28);
            this.lblValor.TabIndex = 57;
            this.lblValor.Text = "Valor *";
            this.lblValor.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // maskData
            // 
            this.maskData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.maskData.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskData.ForeColor = System.Drawing.Color.DimGray;
            this.maskData.Location = new System.Drawing.Point(65, 232);
            this.maskData.Mask = "00 / 00 / 0000";
            this.maskData.Name = "maskData";
            this.maskData.Size = new System.Drawing.Size(350, 24);
            this.maskData.TabIndex = 55;
            this.maskData.ValidatingType = typeof(System.DateTime);
            // 
            // MaskNumInfracao
            // 
            this.MaskNumInfracao.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MaskNumInfracao.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaskNumInfracao.ForeColor = System.Drawing.Color.DimGray;
            this.MaskNumInfracao.Location = new System.Drawing.Point(65, 176);
            this.MaskNumInfracao.Mask = "000-00";
            this.MaskNumInfracao.Name = "MaskNumInfracao";
            this.MaskNumInfracao.Size = new System.Drawing.Size(350, 24);
            this.MaskNumInfracao.TabIndex = 53;
            // 
            // txtValor
            // 
            this.txtValor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.txtValor.ForeColor = System.Drawing.Color.DimGray;
            this.txtValor.Location = new System.Drawing.Point(65, 288);
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(350, 24);
            this.txtValor.TabIndex = 54;
            this.txtValor.Text = " ";
            this.txtValor.TextChanged += new System.EventHandler(this.TxtValor_TextChanged);
            // 
            // tbxFuncionario
            // 
            this.tbxFuncionario.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.tbxFuncionario.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tbxFuncionario.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbxFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.tbxFuncionario.ForeColor = System.Drawing.Color.DimGray;
            this.tbxFuncionario.Location = new System.Drawing.Point(65, 64);
            this.tbxFuncionario.Name = "tbxFuncionario";
            this.tbxFuncionario.Size = new System.Drawing.Size(350, 24);
            this.tbxFuncionario.TabIndex = 51;
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(839, 313);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(0, 13);
            this.lblId.TabIndex = 61;
            this.lblId.Visible = false;
            // 
            // maskedPlaca
            // 
            this.maskedPlaca.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.maskedPlaca.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.maskedPlaca.Dock = System.Windows.Forms.DockStyle.Fill;
            this.maskedPlaca.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.maskedPlaca.ForeColor = System.Drawing.Color.DimGray;
            this.maskedPlaca.Location = new System.Drawing.Point(65, 120);
            this.maskedPlaca.Name = "maskedPlaca";
            this.maskedPlaca.Size = new System.Drawing.Size(350, 24);
            this.maskedPlaca.TabIndex = 62;
            this.maskedPlaca.TextChanged += new System.EventHandler(this.MaskedPlaca_TextChanged);
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Gray;
            this.label11.Dock = System.Windows.Forms.DockStyle.Top;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(0, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(900, 32);
            this.label11.TabIndex = 7;
            this.label11.Text = "Editar Multa";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EditarCadastroMulta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(900, 468);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.label11);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EditarCadastroMulta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditarCadastroMulta";
            this.Load += new System.EventHandler(this.EditarCadastroMulta_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Label labeltesteErro;
        private System.Windows.Forms.Label lblMesagemObrigatoriedade;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label lblId;
        public System.Windows.Forms.MaskedTextBox maskData;
        public System.Windows.Forms.Label lblData;
        public System.Windows.Forms.TextBox txtValor;
        public System.Windows.Forms.Label lblValor;
        public System.Windows.Forms.MaskedTextBox MaskNumInfracao;
        public System.Windows.Forms.Label lblNumeroDaInfracao;
        public System.Windows.Forms.Label lblPlaca;
        public System.Windows.Forms.TextBox tbxFuncionario;
        public System.Windows.Forms.Label lblFuncionario;
        public System.Windows.Forms.TextBox maskedPlaca;
    }
}