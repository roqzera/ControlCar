﻿using PimForms;
using PimForms.Classes;
using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            FuncionarioDao funcionarioDao = new FuncionarioDao();
            List<Funcionario> funcionarios = funcionarioDao.BuscarFuncionario("WWWWW");
            DataTable dataTable = funcionarioDao.BuscarFuncionarioTest("WWWWW");
            string nome = dataTable.Rows[0]["nome"].ToString();
            Console.WriteLine(nome);
            //lista1 = string.Join("", lista1);
            //string lista2 = string.Join("", funcionarios);
            //Console.WriteLine(lista1);

            string str = funcionarios[0].Nome + funcionarios[0].

            Console.ReadKey();
        }
    }
}
