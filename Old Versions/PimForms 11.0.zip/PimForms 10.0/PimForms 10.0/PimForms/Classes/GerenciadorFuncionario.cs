﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PimForms.Formulários;

namespace PimForms.Classes
{
    public class GerenciadorFuncionario
    {
        List<Funcionario> ListaFuncionarios;

        public void AdicionarFuncionario(Funcionario funcionario)
        {
           if(ListaFuncionarios == null)
            {
                ListaFuncionarios = new List<Funcionario>();
            }

            ListaFuncionarios.Add(funcionario);
            FuncionarioDao funcionarioDao = new FuncionarioDao();
            funcionarioDao.AdicionarFuncionario(funcionario);
        }

        /*
        public void BuscarFuncionario(string matricula)
        {
            
            foreach (Funcionario f in ListaFuncionarios)
            {
                if (f.Matricula == matricula)
                {
                    FuncionarioDao funcionarioDao = new FuncionarioDao();
                    funcionarioDao.BuscarFuncionario(f.Matricula);
                }
            }
            

            for (int cont = 0; cont < ListaFuncionarios.Count; cont++)
            {
                if (ListaFuncionarios[cont].Matricula == matricula)
                {
                    FuncionarioDao funcionarioDao = new FuncionarioDao();
                    funcionarioDao.BuscarFuncionario(ListaFuncionarios[cont].Matricula);
                }
            }
        }
        */
    }
}

