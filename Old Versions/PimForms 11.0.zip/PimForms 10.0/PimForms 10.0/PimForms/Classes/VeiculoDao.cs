﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PimForms.Classes
{
    class VeiculoDao
    {
        MySqlCommand cmd = new MySqlCommand();
        ConexaoBanco conexao = new ConexaoBanco();
        MySqlConnection mySqlConnection;

        public void AdicionarVeiculo(Veiculo veiculo)
        {

            //Comando Sql: insert, update, delete

            cmd.CommandText = "INSERT INTO veiculos (placa, numero_renavam, marca, modelo, motor, cor, ano, quilometragem) " +
                "VALUES (@Placa, @NumeroRenavam, @Marca, @Modelo, @Motor, @Cor, @Ano, @Quilometragem)";

            //Parametros

            cmd.Parameters.AddWithValue("@Placa", veiculo.Placa);
            cmd.Parameters.AddWithValue("@NumeroRenavam", veiculo.NumeroRenavam);
            cmd.Parameters.AddWithValue("@Marca", veiculo.Marca);
            cmd.Parameters.AddWithValue("@Modelo", veiculo.Modelo);
            cmd.Parameters.AddWithValue("@Motor", veiculo.Motor);
            cmd.Parameters.AddWithValue("@Cor", veiculo.Cor);
            cmd.Parameters.AddWithValue("@Ano", veiculo.Ano);
            cmd.Parameters.AddWithValue("@Quilometragem", veiculo.Quilometragem);

            try
            {
                //Conectar com o banco
                cmd.Connection = conexao.Conectar();
                //Executar Comando
                cmd.ExecuteNonQuery();
                //Desconectar
                conexao.Desconectar();
                //Mostrar mensagem de sucesso/erro
                MessageBox.Show("Cadastro realizado com sucesso!");
            }

            catch (MySqlException)
            {
                //MessageBox.Show("Erro ao tentar se conectar com o banco de dados");
                //throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }

        public string ListarVeiculos()
        {
            string strMysql = "SELECT * FROM veiculos";

            return strMysql;
        }

        public string BuscarVeiculo(string placa)
        {

            string strMysql = "SELECT * FROM veiculos WHERE placa ='" + placa + "';";

            return strMysql;
        }
        public void EditarVeiculo(string placa,
            string numero_renavam,
            string marca,
            string modelo,
            string motor,
            string cor,
            string ano,
            string quilometragem,
            string id_veiculo
            )
        {

            cmd.CommandText = "UPDATE veiculos SET placa=@placa, numero_renavam=@numero_renavam, marca=@marca, modelo=@modelo, motor=@motor, cor=@cor, ano=@ano, quilometragem=@quilometragem WHERE id_veiculo = @id_veiculo;";

            cmd.Parameters.AddWithValue("@placa", placa);
            cmd.Parameters.AddWithValue("@numero_renavam", numero_renavam);
            cmd.Parameters.AddWithValue("@marca", marca);
            cmd.Parameters.AddWithValue("@modelo", modelo);
            cmd.Parameters.AddWithValue("@motor", motor);
            cmd.Parameters.AddWithValue("@cor", cor);
            cmd.Parameters.AddWithValue("@ano", ano);
            cmd.Parameters.AddWithValue("@quilometragem", quilometragem);
            cmd.Parameters.AddWithValue("@id_veiculo", id_veiculo);

            try
            {
                cmd.Connection = conexao.Conectar();
                cmd.ExecuteNonQuery();
                conexao.Desconectar();
                MessageBox.Show("Cadastro atualizado com sucesso!");
            }

            catch (MySqlException ex)
            {
                MessageBox.Show("Erro ao tentar se conectar com o banco de dados");
                throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }

        public void ExcluirVeiculo(string id_veiculo)
        {
            cmd.CommandText = "DELETE FROM veiculos WHERE id_veiculo =" + id_veiculo;

            try
            {
                cmd.Connection = conexao.Conectar();
                cmd.ExecuteNonQuery();
                conexao.Desconectar();
            }

            catch (MySqlException ex)
            {
                MessageBox.Show("Erro ao tentar se conectar com o banco de dados");
                throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }

        public DataTable ExibirNoDataGridView(string strCon)
        {
            try
            {
                mySqlConnection = conexao.Conectar();
                cmd = new MySqlCommand(strCon, mySqlConnection);

                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter();
                // Seleciona os dados do banco e preenche o DataAdapter com esses dados
                mySqlDataAdapter.SelectCommand = cmd;

                DataTable dataTable = new DataTable();
                // Armazena no DataTable os dados que foram buscados no banco com o uso do SelectCommand
                mySqlDataAdapter.Fill(dataTable);

                return dataTable;
            }

            catch (MySqlException ex)
            {
                throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }
    
}
}
