﻿using PimForms.Formulários;
using PimForms.SubMenus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PimForms.models
{
    public partial class FormSubMenuFuncionario : Form
    {
        Formularios form = new Formularios();
        public FormSubMenuFuncionario()
        {
            InitializeComponent();
        }

        private void Panel10_Paint(object sender, PaintEventArgs e)
        {

        }

        private void TableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnCadastrarSubMenu_Click(object sender, EventArgs e)
        {
            form.AbrirSubMenu<CadastrarFuncionario>(pnlFormularios);
            MudaCorDaFonte(btnCadastrarSubMenu, btnConsultarSubMenuFuncionario, btnMultaSubMenuFuncionario);
        }

        private void BtnConsultarSubMenuFuncionario_Click(object sender, EventArgs e)
        {
            form.AbrirSubMenu<ListarFuncionario>(pnlFormularios);
            MudaCorDaFonte(btnConsultarSubMenuFuncionario, btnCadastrarSubMenu, btnMultaSubMenuFuncionario);
        }

        private void BtnMultaSubMenuFuncionario_Click(object sender, EventArgs e)
        {
            MudaCorDaFonte(btnMultaSubMenuFuncionario, btnConsultarSubMenuFuncionario, btnCadastrarSubMenu);
        }

        public void MudaCorDaFonte(Button button1, Button button2, Button button3)
        {
            button1.BackColor = Color.DarkSeaGreen;
            button1.ForeColor = Color.White;

            button2.BackColor = Color.LightGray;
            button2.ForeColor = Color.Gray;

            button3.BackColor = Color.LightGray;
            button3.ForeColor = Color.Gray;
        }
    }
}
