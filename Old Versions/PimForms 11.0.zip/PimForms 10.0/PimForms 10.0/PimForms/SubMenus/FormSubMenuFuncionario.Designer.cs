﻿namespace PimForms.models
{
    partial class FormSubMenuFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlFormularios = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnMultaSubMenuFuncionario = new System.Windows.Forms.Button();
            this.btnConsultarSubMenuFuncionario = new System.Windows.Forms.Button();
            this.btnCadastrarSubMenu = new System.Windows.Forms.Button();
            this.pnlIndicador1 = new System.Windows.Forms.Panel();
            this.pnlIndicador2 = new System.Windows.Forms.Panel();
            this.pnlIndicador3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlFormularios
            // 
            this.pnlFormularios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlFormularios.BackColor = System.Drawing.Color.White;
            this.pnlFormularios.Location = new System.Drawing.Point(160, 0);
            this.pnlFormularios.Margin = new System.Windows.Forms.Padding(0);
            this.pnlFormularios.Name = "pnlFormularios";
            this.pnlFormularios.Size = new System.Drawing.Size(640, 340);
            this.pnlFormularios.TabIndex = 0;
            this.pnlFormularios.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1_Paint);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel2.Controls.Add(this.pnlFormularios, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(800, 340);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.LightGray;
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel1, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.Size = new System.Drawing.Size(160, 340);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 3F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 97F));
            this.tableLayoutPanel1.Controls.Add(this.btnMultaSubMenuFuncionario, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.btnConsultarSubMenuFuncionario, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnCadastrarSubMenu, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.pnlIndicador1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pnlIndicador2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.pnlIndicador3, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.button1, 1, 6);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 32);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.41667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.083333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.41667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.083333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.41667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.083333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.41667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.08333F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(160, 308);
            this.tableLayoutPanel1.TabIndex = 1;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.TableLayoutPanel1_Paint);
            // 
            // btnMultaSubMenuFuncionario
            // 
            this.btnMultaSubMenuFuncionario.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMultaSubMenuFuncionario.FlatAppearance.BorderSize = 0;
            this.btnMultaSubMenuFuncionario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnMultaSubMenuFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMultaSubMenuFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultaSubMenuFuncionario.ForeColor = System.Drawing.Color.DimGray;
            this.btnMultaSubMenuFuncionario.Location = new System.Drawing.Point(4, 76);
            this.btnMultaSubMenuFuncionario.Margin = new System.Windows.Forms.Padding(0);
            this.btnMultaSubMenuFuncionario.Name = "btnMultaSubMenuFuncionario";
            this.btnMultaSubMenuFuncionario.Size = new System.Drawing.Size(156, 32);
            this.btnMultaSubMenuFuncionario.TabIndex = 5;
            this.btnMultaSubMenuFuncionario.Text = "Cadastrar Multa";
            this.btnMultaSubMenuFuncionario.UseVisualStyleBackColor = true;
            this.btnMultaSubMenuFuncionario.Click += new System.EventHandler(this.BtnMultaSubMenuFuncionario_Click);
            // 
            // btnConsultarSubMenuFuncionario
            // 
            this.btnConsultarSubMenuFuncionario.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnConsultarSubMenuFuncionario.FlatAppearance.BorderSize = 0;
            this.btnConsultarSubMenuFuncionario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnConsultarSubMenuFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConsultarSubMenuFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultarSubMenuFuncionario.ForeColor = System.Drawing.Color.DimGray;
            this.btnConsultarSubMenuFuncionario.Location = new System.Drawing.Point(4, 38);
            this.btnConsultarSubMenuFuncionario.Margin = new System.Windows.Forms.Padding(0);
            this.btnConsultarSubMenuFuncionario.Name = "btnConsultarSubMenuFuncionario";
            this.btnConsultarSubMenuFuncionario.Size = new System.Drawing.Size(156, 32);
            this.btnConsultarSubMenuFuncionario.TabIndex = 4;
            this.btnConsultarSubMenuFuncionario.Text = "Consultar Funcionários";
            this.btnConsultarSubMenuFuncionario.UseVisualStyleBackColor = true;
            this.btnConsultarSubMenuFuncionario.Click += new System.EventHandler(this.BtnConsultarSubMenuFuncionario_Click);
            // 
            // btnCadastrarSubMenu
            // 
            this.btnCadastrarSubMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCadastrarSubMenu.FlatAppearance.BorderSize = 0;
            this.btnCadastrarSubMenu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnCadastrarSubMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastrarSubMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrarSubMenu.ForeColor = System.Drawing.Color.DimGray;
            this.btnCadastrarSubMenu.Location = new System.Drawing.Point(4, 0);
            this.btnCadastrarSubMenu.Margin = new System.Windows.Forms.Padding(0);
            this.btnCadastrarSubMenu.Name = "btnCadastrarSubMenu";
            this.btnCadastrarSubMenu.Size = new System.Drawing.Size(156, 32);
            this.btnCadastrarSubMenu.TabIndex = 3;
            this.btnCadastrarSubMenu.Text = "Cadastrar Funcionário";
            this.btnCadastrarSubMenu.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnCadastrarSubMenu.UseVisualStyleBackColor = true;
            this.btnCadastrarSubMenu.Click += new System.EventHandler(this.BtnCadastrarSubMenu_Click);
            // 
            // pnlIndicador1
            // 
            this.pnlIndicador1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnlIndicador1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlIndicador1.Location = new System.Drawing.Point(0, 0);
            this.pnlIndicador1.Margin = new System.Windows.Forms.Padding(0);
            this.pnlIndicador1.Name = "pnlIndicador1";
            this.pnlIndicador1.Size = new System.Drawing.Size(4, 32);
            this.pnlIndicador1.TabIndex = 2;
            this.pnlIndicador1.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel10_Paint);
            // 
            // pnlIndicador2
            // 
            this.pnlIndicador2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnlIndicador2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlIndicador2.Location = new System.Drawing.Point(0, 38);
            this.pnlIndicador2.Margin = new System.Windows.Forms.Padding(0);
            this.pnlIndicador2.Name = "pnlIndicador2";
            this.pnlIndicador2.Size = new System.Drawing.Size(4, 32);
            this.pnlIndicador2.TabIndex = 2;
            this.pnlIndicador2.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel9_Paint);
            // 
            // pnlIndicador3
            // 
            this.pnlIndicador3.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnlIndicador3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlIndicador3.Location = new System.Drawing.Point(0, 76);
            this.pnlIndicador3.Margin = new System.Windows.Forms.Padding(0);
            this.pnlIndicador3.Name = "pnlIndicador3";
            this.pnlIndicador3.Size = new System.Drawing.Size(4, 32);
            this.pnlIndicador3.TabIndex = 2;
            this.pnlIndicador3.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel8_Paint);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 114);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(4, 32);
            this.panel1.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.DimGray;
            this.button1.Location = new System.Drawing.Point(4, 114);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(156, 32);
            this.button1.TabIndex = 7;
            this.button1.Text = "Cadastrar Multa";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // FormSubMenuFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 340);
            this.Controls.Add(this.tableLayoutPanel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormSubMenuFuncionario";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        protected System.Windows.Forms.Panel pnlIndicador1;
        protected System.Windows.Forms.Panel pnlIndicador2;
        protected System.Windows.Forms.Panel pnlIndicador3;
        protected System.Windows.Forms.Button btnCadastrarSubMenu;
        protected System.Windows.Forms.Button btnConsultarSubMenuFuncionario;
        protected System.Windows.Forms.Button btnMultaSubMenuFuncionario;
        public System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        public System.Windows.Forms.Panel pnlFormularios;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        protected System.Windows.Forms.Panel panel1;
        protected System.Windows.Forms.Button button1;
    }
}