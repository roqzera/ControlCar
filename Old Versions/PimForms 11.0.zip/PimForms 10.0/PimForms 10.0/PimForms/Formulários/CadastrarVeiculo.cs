﻿using PimForms.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PimForms
{
    public partial class CadastrarVeiculo : Form
    {
        public CadastrarVeiculo()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void LblTituloForm_Click(object sender, EventArgs e)
        {

        }

        private void LblMarca_Click(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void ComboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            
        }
        public void Validacao(Veiculo veiculo)
        {
            if (veiculo.IsPlaca(maskedPlaca.Text) == false)
            {
                labeltesteErro.Text = "* Placa incorreta. É necessário ter 3 letras e 4 números para obter uma Placa válida.";
                maskedPlaca.Text = string.Empty;
            }
            else
            {
                if (veiculo.IsRenavam(maskedRenavam.Text) == false)
                {
                    labeltesteErro.Text = "* Renavam incorreto. É necessário 11 números para obter um Renavam válido.";
                    maskedRenavam.Text = string.Empty;
                }
            }
        }
        private void Label1_Click_1(object sender, EventArgs e)
        {

        }

        private void BtnAdicionar_Click(object sender, EventArgs e)
        {
            Veiculo cad = new Veiculo(maskedPlaca.Text,
                maskedRenavam.Text,
                cmbMarca.Text,
                cmbModelo.Text,
                cmbMotor.Text,
                cmbCor.Text,
                cmbAno.Text,
                Convert.ToDecimal(tbxKm.Text));

            VeiculoGerenciador banco = new VeiculoGerenciador();
            banco.AdicionarVeiculo(cad);

            Validacao(cad);

            if (cad.Placa != null
                && cad.NumeroRenavam != null
                && cad.Marca != null
                && cad.Modelo != null
                && cad.Motor != null
                && cad.Cor != null
                && cad.Ano != null
                )
            {
                labeltesteErro.Text = string.Empty;
            }
        }

        private void Button1_Click_1(object sender, EventArgs e)
        {

        }

        private void TableLayoutPanel1_Paint_2(object sender, PaintEventArgs e)
        {

        }

        private void MaskedPlaca_Click(object sender, EventArgs e)
        {
            maskedPlaca.Focus();
            maskedPlaca.SelectionStart = 0;
        }

        private void MaskedPlaca_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedRenavam_Click(object sender, EventArgs e)
        {
            maskedRenavam.Focus();
            maskedRenavam.SelectionStart = 0;
        }
    }
}
