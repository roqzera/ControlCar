﻿using PimForms.Classes;
using PimForms.SubMenus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PimForms.Formulários
{
    public partial class ListarVeiculos : Form
    {
        public ListarVeiculos()
        {
            InitializeComponent();
            Listar();
        }
        Formularios form = new Formularios();

        private void Listar()
        {
            VeiculoDao veiculoDao = new VeiculoDao();
            //strMysql armazena o retorno do método BuscarFuncionario(), que é uma string de comando MySql. 
            string strMysql = veiculoDao.ListarVeiculos();
            // A string strMysql é passada por parâmetro para que o método ExibirNoDataGridView() possa fazer a conexão com o banco e exibir os dados buscados no DataGridView
            dataGridListar.DataSource = veiculoDao.ExibirNoDataGridView(strMysql);
            dataGridListar.Columns["id_veiculo"].Visible = false;
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            Listar();
        }

        private void DataGridListar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ListarVeiculos_Load(object sender, EventArgs e)
        {

        }

        private void ToolStripButton1_Click_1(object sender, EventArgs e)
        {
            Listar();
        }

        private void ToolStripButtonExcluir_Click(object sender, EventArgs e)
        {
            string idVeiculo;

            if (dataGridListar.SelectedRows.Count > 0)
            {
                idVeiculo = dataGridListar.CurrentRow.Cells["id_veiculo"].Value.ToString();
                VeiculoDao veiculoDao = new VeiculoDao();
                veiculoDao.ExcluirVeiculo(idVeiculo);
            }

            Listar();
        }

        private void ToolStripButtonPesquisar_Click(object sender, EventArgs e)
        {
            string placa = Convert.ToString(toolStripTextBoxPlaca.Text);

            VeiculoDao veiculoDao = new VeiculoDao();
            //strMysql armazena o retorno do método BuscarFuncionario(), que é uma string de comando MySql. 
            string strMysql = veiculoDao.BuscarVeiculo(placa);
            // A string strMysql é passada por parâmetro para que o método ExibirNoDataGridView() possa fazer a conexão com o banco e exibir os dados buscados no DataGridView
            dataGridListar.DataSource = veiculoDao.ExibirNoDataGridView(strMysql);
        }

        private void ToolStripButtonEditar_Click(object sender, EventArgs e)
        {

        }

        private void ToolStripButtonListar_Click(object sender, EventArgs e)
        {
            Listar();
        }
    }
}
