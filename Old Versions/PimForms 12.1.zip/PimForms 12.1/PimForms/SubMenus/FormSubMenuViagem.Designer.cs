﻿namespace PimForms.SubMenus
{
    partial class FormSubMenuViagem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlFormularios = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnConsultarSubMenuVeiculos = new System.Windows.Forms.Button();
            this.btnCadastrarSubMenuVeiculos = new System.Windows.Forms.Button();
            this.pnlIndicador1 = new System.Windows.Forms.Panel();
            this.pnlIndicador2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlFormularios
            // 
            this.pnlFormularios.BackColor = System.Drawing.Color.White;
            this.pnlFormularios.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlFormularios.Location = new System.Drawing.Point(160, 0);
            this.pnlFormularios.Margin = new System.Windows.Forms.Padding(0);
            this.pnlFormularios.Name = "pnlFormularios";
            this.pnlFormularios.Size = new System.Drawing.Size(640, 340);
            this.pnlFormularios.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel2.Controls.Add(this.pnlFormularios, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(800, 340);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel1, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.Size = new System.Drawing.Size(160, 340);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 3F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 97F));
            this.tableLayoutPanel1.Controls.Add(this.btnConsultarSubMenuVeiculos, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnCadastrarSubMenuVeiculos, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.pnlIndicador1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pnlIndicador2, 0, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 32);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.41667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.083333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.41667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.083333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.41667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.083333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.41667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.08333F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(160, 308);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // btnConsultarSubMenuVeiculos
            // 
            this.btnConsultarSubMenuVeiculos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnConsultarSubMenuVeiculos.FlatAppearance.BorderSize = 0;
            this.btnConsultarSubMenuVeiculos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnConsultarSubMenuVeiculos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConsultarSubMenuVeiculos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultarSubMenuVeiculos.ForeColor = System.Drawing.Color.DimGray;
            this.btnConsultarSubMenuVeiculos.Location = new System.Drawing.Point(4, 38);
            this.btnConsultarSubMenuVeiculos.Margin = new System.Windows.Forms.Padding(0);
            this.btnConsultarSubMenuVeiculos.Name = "btnConsultarSubMenuVeiculos";
            this.btnConsultarSubMenuVeiculos.Size = new System.Drawing.Size(156, 32);
            this.btnConsultarSubMenuVeiculos.TabIndex = 4;
            this.btnConsultarSubMenuVeiculos.Text = "Consultar Viagens";
            this.btnConsultarSubMenuVeiculos.UseVisualStyleBackColor = true;
            // 
            // btnCadastrarSubMenuVeiculos
            // 
            this.btnCadastrarSubMenuVeiculos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCadastrarSubMenuVeiculos.FlatAppearance.BorderSize = 0;
            this.btnCadastrarSubMenuVeiculos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnCadastrarSubMenuVeiculos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastrarSubMenuVeiculos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrarSubMenuVeiculos.ForeColor = System.Drawing.Color.DimGray;
            this.btnCadastrarSubMenuVeiculos.Location = new System.Drawing.Point(4, 0);
            this.btnCadastrarSubMenuVeiculos.Margin = new System.Windows.Forms.Padding(0);
            this.btnCadastrarSubMenuVeiculos.Name = "btnCadastrarSubMenuVeiculos";
            this.btnCadastrarSubMenuVeiculos.Size = new System.Drawing.Size(156, 32);
            this.btnCadastrarSubMenuVeiculos.TabIndex = 3;
            this.btnCadastrarSubMenuVeiculos.Text = "Cadastrar Viagem";
            this.btnCadastrarSubMenuVeiculos.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnCadastrarSubMenuVeiculos.UseVisualStyleBackColor = true;
            this.btnCadastrarSubMenuVeiculos.Click += new System.EventHandler(this.BtnCadastrarSubMenu_Click);
            // 
            // pnlIndicador1
            // 
            this.pnlIndicador1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnlIndicador1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlIndicador1.Location = new System.Drawing.Point(0, 0);
            this.pnlIndicador1.Margin = new System.Windows.Forms.Padding(0);
            this.pnlIndicador1.Name = "pnlIndicador1";
            this.pnlIndicador1.Size = new System.Drawing.Size(4, 32);
            this.pnlIndicador1.TabIndex = 2;
            // 
            // pnlIndicador2
            // 
            this.pnlIndicador2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnlIndicador2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlIndicador2.Location = new System.Drawing.Point(0, 38);
            this.pnlIndicador2.Margin = new System.Windows.Forms.Padding(0);
            this.pnlIndicador2.Name = "pnlIndicador2";
            this.pnlIndicador2.Size = new System.Drawing.Size(4, 32);
            this.pnlIndicador2.TabIndex = 2;
            // 
            // FormSubMenuViagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 340);
            this.Controls.Add(this.tableLayoutPanel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormSubMenuViagem";
            this.Text = "FormSubMenuViagem";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Panel pnlFormularios;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        public System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        protected System.Windows.Forms.Button btnConsultarSubMenuVeiculos;
        protected System.Windows.Forms.Button btnCadastrarSubMenuVeiculos;
        protected System.Windows.Forms.Panel pnlIndicador1;
        protected System.Windows.Forms.Panel pnlIndicador2;
    }
}