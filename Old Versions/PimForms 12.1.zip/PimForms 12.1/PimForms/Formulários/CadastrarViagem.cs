﻿using PimForms.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace PimForms.Formulários
{
    public partial class CadastrarViagem : Form
    {
        public CadastrarViagem()
        {
            InitializeComponent();
        }

        VeiculoDao veic = new VeiculoDao();
        FuncionarioDao fun = new FuncionarioDao();
        AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
        private void CadastrarViagem_Load_1(object sender, EventArgs e)
        {

            for (int i = 0; i < fun.AutoComplete().Length; i++)
            {
                tbxMatricula.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                tbxMatricula.AutoCompleteSource = AutoCompleteSource.CustomSource;
                tbxMatricula.AutoCompleteCustomSource.Add(fun.AutoComplete()[i]);
            }
            for (int i = 0; i < veic.AutoComplete().Length; i++)
            {
                tbxPlaca.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                tbxPlaca.AutoCompleteSource = AutoCompleteSource.CustomSource;
                tbxPlaca.AutoCompleteCustomSource.Add(veic.AutoComplete()[i]);
            }

        }
                   
        private void LblMatricula_Click(object sender, EventArgs e)
        {

        }

        private void BtnAdicionar_Click(object sender, EventArgs e)
        {
            Viagem viagem = new Viagem(
                Convert.ToDateTime(maskedDataSaida.Text),
                Convert.ToDateTime(maskedDataRetorno.Text),
                Convert.ToString(tbxDestino.Text),
                Convert.ToDecimal(maskValorAdiantamento.Text),
                Convert.ToDecimal(tbxKmInicial.Text),
                Convert.ToDecimal(tbxKmFinal.Text),
                Convert.ToChar(tbxQtdOcupantes.Text),
                Convert.ToInt32(fun.BuscarIdFuncionario(tbxMatricula.Text)),
                Convert.ToInt32(veic.BuscarIdVeiculo(tbxPlaca.Text))
                );
            GerenciadorViagem gerenciadorViagem = new GerenciadorViagem();
            gerenciadorViagem.AdicionarViagem(viagem);
        }

        private void TbxMatricula_TextChanged(object sender, EventArgs e)
        {
        }

        private void TableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void TbxPlaca_TextChanged(object sender, EventArgs e)
        {

        }

        private void MaskedDataSaida_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
