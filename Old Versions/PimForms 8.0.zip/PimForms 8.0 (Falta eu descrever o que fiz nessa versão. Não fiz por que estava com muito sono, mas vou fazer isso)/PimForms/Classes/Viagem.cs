﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PimForms
{
    class Viagem
    {

        public int idViagem { get; set; }

        public DateTime DataSaida { get; set; }

        public DateTime DataEntrada { get; set; }

        public string Destino { get; set; }

        public decimal ValorAdiantamento { get; set; }

        public decimal KmInicial { get; set; }

        public decimal KmFinal { get; set; }


    }
}
