﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;


namespace PimForms.Classes
{
    public class FuncionarioDao
    {
        MySqlCommand cmd = new MySqlCommand();
        ConexaoBanco conexao = new ConexaoBanco();
        MySqlConnection mySqlConnection;

        public void AdicionarFuncionario(Funcionario funcionario)
        {

            cmd.CommandText = "INSERT INTO funcionario(" +
                "matricula, nome, cpf, data_nascimento, telefone, cargo, email, numero_cnh, categoria_cnh, validade_cnh)" +
                "VALUES (@matricula, @nome, @cpf, @data_nascimento, @telefone, @cargo, @email, @numero_cnh, @categoria_cnh, @validade_cnh)";

            // Cria um novo objeto do tipo MySqlCommand recebendo como parâmetro a string de acesso e o objeto de conexão. 

            cmd.Parameters.AddWithValue("@matricula", funcionario.Matricula);
            cmd.Parameters.AddWithValue("@nome", funcionario.Nome);
            cmd.Parameters.AddWithValue("@cpf", funcionario.CPF);
            cmd.Parameters.AddWithValue("@data_nascimento", funcionario.DataDeNascimento);
            cmd.Parameters.AddWithValue("@telefone", funcionario.Telefone);
            cmd.Parameters.AddWithValue("@cargo", funcionario.Cargo);
            cmd.Parameters.AddWithValue("@email", funcionario.Email);
            cmd.Parameters.AddWithValue("@numero_cnh", funcionario.NumeroCNH);
            cmd.Parameters.AddWithValue("@categoria_cnh", funcionario.CategoriaCNH);
            cmd.Parameters.AddWithValue("@validade_cnh", funcionario.ValidadeCNH);

            try
            {
                //Conectar com o banco
                cmd.Connection = conexao.Conectar();
                //Executar Comando
                cmd.ExecuteNonQuery();
                //Desconectar
                conexao.Desconectar();
                //Mostrar mensagem de sucesso/erro
                MessageBox.Show("Cadastro realizado com sucesso!");
            }

            catch (MySqlException)
            {
                //MessageBox.Show("Erro ao tentar se conectar com o banco de dados");
                //throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }

        public string ListarFuncionarios()
        {
            string strMysql = "SELECT * FROM funcionario";

            return strMysql;
        }

        public string BuscarFuncionario(string matricula)
        {

            string strMysql = "SELECT * FROM funcionario WHERE matricula =" + matricula;

            return strMysql;
        }

        public void EditarFuncionario(string matricula,
            string nome,
            string cpf,
            string data_nascimento,
            string telefone,
            string cargo,
            string email,
            string numero_cnh,
            string categoria_cnh,
            string validade_cnh,
            string id_funcionario
            )
        {

            cmd.CommandText = "UPDATE funcionario SET nome=@nome, cpf=@cpf, data_nascimento=@data_nascimento, telefone=@telefone, cargo=@cargo, email=@email, numero_cnh=@numero_cnh, categoria_cnh=@categoria_cnh, validade_cnh=@validade_cnh WHERE id_funcionario = @id_funcionario;";

            cmd.Parameters.AddWithValue("@nome", nome);
            cmd.Parameters.AddWithValue("@cpf", cpf);
            cmd.Parameters.AddWithValue("@data_nascimento",data_nascimento);
            cmd.Parameters.AddWithValue("@telefone", telefone);
            cmd.Parameters.AddWithValue("@cargo", cargo);
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@numero_cnh", numero_cnh);
            cmd.Parameters.AddWithValue("@categoria_cnh", categoria_cnh);
            cmd.Parameters.AddWithValue("@validade_cnh", validade_cnh);
            cmd.Parameters.AddWithValue("@id_funcionario", id_funcionario);

            try
            {
                cmd.Connection = conexao.Conectar();
                cmd.ExecuteNonQuery();
                conexao.Desconectar();
                MessageBox.Show("Cadastro atualizado com sucesso!");
            }

            catch (MySqlException ex)
            {
                MessageBox.Show("Erro ao tentar se conectar com o banco de dados");
                throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }

        public void ExcluirFuncionario(string id_funcionario)
        {
            cmd.CommandText = "DELETE FROM funcionario WHERE id_funcionario =" + id_funcionario;

            try
            {
                cmd.Connection = conexao.Conectar();
                cmd.ExecuteNonQuery();
                conexao.Desconectar();
            }

            catch (MySqlException ex)
            {
                MessageBox.Show("Erro ao tentar se conectar com o banco de dados");
                throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }

        public DataTable ExibirNoDataGridView(string strCon)
        {
            try
            {
                mySqlConnection = conexao.Conectar();
                cmd = new MySqlCommand(strCon, mySqlConnection);

                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter();
                // Seleciona os dados do banco e preenche o DataAdapter com esses dados
                mySqlDataAdapter.SelectCommand = cmd; 

                DataTable dataTable = new DataTable();
                // Armazena no DataTable os dados que foram buscados no banco com o uso do SelectCommand
                mySqlDataAdapter.Fill(dataTable);

                return dataTable;
            }

            catch (MySqlException ex)
            {
                throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }
    }
}
    


