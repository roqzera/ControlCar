﻿namespace PimForms.SubMenus
{
    partial class FormSubMenuVeiculos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlFormularios = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pnlIndicador1 = new System.Windows.Forms.Panel();
            this.pnlIndicador2 = new System.Windows.Forms.Panel();
            this.pnlIndicador3 = new System.Windows.Forms.Panel();
            this.pnlIndicador4 = new System.Windows.Forms.Panel();
            this.btnSubMenu1 = new System.Windows.Forms.Button();
            this.btnSubMenu2 = new System.Windows.Forms.Button();
            this.btnSubMenu3 = new System.Windows.Forms.Button();
            this.btnSubMenu4 = new System.Windows.Forms.Button();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlFormularios
            // 
            this.pnlFormularios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlFormularios.BackColor = System.Drawing.Color.White;
            this.pnlFormularios.Location = new System.Drawing.Point(160, 0);
            this.pnlFormularios.Margin = new System.Windows.Forms.Padding(0);
            this.pnlFormularios.Name = "pnlFormularios";
            this.pnlFormularios.Size = new System.Drawing.Size(640, 340);
            this.pnlFormularios.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel2.Controls.Add(this.pnlFormularios, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(800, 340);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.LightGray;
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel1, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.Size = new System.Drawing.Size(160, 340);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 98F));
            this.tableLayoutPanel1.Controls.Add(this.pnlIndicador1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pnlIndicador2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.pnlIndicador3, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.pnlIndicador4, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.btnSubMenu1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnSubMenu2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnSubMenu3, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.btnSubMenu4, 1, 6);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 32);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(160, 308);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // pnlIndicador1
            // 
            this.pnlIndicador1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnlIndicador1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlIndicador1.Location = new System.Drawing.Point(0, 0);
            this.pnlIndicador1.Margin = new System.Windows.Forms.Padding(0);
            this.pnlIndicador1.Name = "pnlIndicador1";
            this.pnlIndicador1.Size = new System.Drawing.Size(3, 30);
            this.pnlIndicador1.TabIndex = 2;
            // 
            // pnlIndicador2
            // 
            this.pnlIndicador2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnlIndicador2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlIndicador2.Location = new System.Drawing.Point(0, 45);
            this.pnlIndicador2.Margin = new System.Windows.Forms.Padding(0);
            this.pnlIndicador2.Name = "pnlIndicador2";
            this.pnlIndicador2.Size = new System.Drawing.Size(3, 30);
            this.pnlIndicador2.TabIndex = 2;
            // 
            // pnlIndicador3
            // 
            this.pnlIndicador3.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnlIndicador3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlIndicador3.Location = new System.Drawing.Point(0, 90);
            this.pnlIndicador3.Margin = new System.Windows.Forms.Padding(0);
            this.pnlIndicador3.Name = "pnlIndicador3";
            this.pnlIndicador3.Size = new System.Drawing.Size(3, 30);
            this.pnlIndicador3.TabIndex = 2;
            // 
            // pnlIndicador4
            // 
            this.pnlIndicador4.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnlIndicador4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlIndicador4.Location = new System.Drawing.Point(0, 135);
            this.pnlIndicador4.Margin = new System.Windows.Forms.Padding(0);
            this.pnlIndicador4.Name = "pnlIndicador4";
            this.pnlIndicador4.Size = new System.Drawing.Size(3, 30);
            this.pnlIndicador4.TabIndex = 1;
            // 
            // btnSubMenu1
            // 
            this.btnSubMenu1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubMenu1.FlatAppearance.BorderSize = 0;
            this.btnSubMenu1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubMenu1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubMenu1.ForeColor = System.Drawing.Color.Black;
            this.btnSubMenu1.Location = new System.Drawing.Point(3, 0);
            this.btnSubMenu1.Margin = new System.Windows.Forms.Padding(0);
            this.btnSubMenu1.Name = "btnSubMenu1";
            this.btnSubMenu1.Size = new System.Drawing.Size(157, 30);
            this.btnSubMenu1.TabIndex = 3;
            this.btnSubMenu1.Text = "Cadastrar Veículo";
            this.btnSubMenu1.UseVisualStyleBackColor = true;
            this.btnSubMenu1.Click += new System.EventHandler(this.BtnSubMenu1_Click);
            // 
            // btnSubMenu2
            // 
            this.btnSubMenu2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubMenu2.FlatAppearance.BorderSize = 0;
            this.btnSubMenu2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubMenu2.Location = new System.Drawing.Point(3, 45);
            this.btnSubMenu2.Margin = new System.Windows.Forms.Padding(0);
            this.btnSubMenu2.Name = "btnSubMenu2";
            this.btnSubMenu2.Size = new System.Drawing.Size(157, 30);
            this.btnSubMenu2.TabIndex = 4;
            this.btnSubMenu2.UseVisualStyleBackColor = true;
            // 
            // btnSubMenu3
            // 
            this.btnSubMenu3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubMenu3.FlatAppearance.BorderSize = 0;
            this.btnSubMenu3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubMenu3.Location = new System.Drawing.Point(3, 90);
            this.btnSubMenu3.Margin = new System.Windows.Forms.Padding(0);
            this.btnSubMenu3.Name = "btnSubMenu3";
            this.btnSubMenu3.Size = new System.Drawing.Size(157, 30);
            this.btnSubMenu3.TabIndex = 5;
            this.btnSubMenu3.UseVisualStyleBackColor = true;
            // 
            // btnSubMenu4
            // 
            this.btnSubMenu4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubMenu4.FlatAppearance.BorderSize = 0;
            this.btnSubMenu4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubMenu4.Location = new System.Drawing.Point(3, 135);
            this.btnSubMenu4.Margin = new System.Windows.Forms.Padding(0);
            this.btnSubMenu4.Name = "btnSubMenu4";
            this.btnSubMenu4.Size = new System.Drawing.Size(157, 30);
            this.btnSubMenu4.TabIndex = 6;
            this.btnSubMenu4.UseVisualStyleBackColor = true;
            // 
            // FormSubMenuVeiculos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 340);
            this.Controls.Add(this.tableLayoutPanel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormSubMenuVeiculos";
            this.Text = "FormSubMenuVeiculos";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Panel pnlFormularios;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        public System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        protected System.Windows.Forms.Panel pnlIndicador1;
        protected System.Windows.Forms.Panel pnlIndicador2;
        protected System.Windows.Forms.Panel pnlIndicador3;
        protected System.Windows.Forms.Panel pnlIndicador4;
        protected System.Windows.Forms.Button btnSubMenu1;
        protected System.Windows.Forms.Button btnSubMenu2;
        protected System.Windows.Forms.Button btnSubMenu3;
        protected System.Windows.Forms.Button btnSubMenu4;
    }
}