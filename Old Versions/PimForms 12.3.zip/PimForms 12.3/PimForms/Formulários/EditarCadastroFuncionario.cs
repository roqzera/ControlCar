﻿using PimForms.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PimForms.Formulários
{
    public partial class EditarCadastroFuncionario : Form
    {
        public EditarCadastroFuncionario()
        {
            InitializeComponent();
        }

        private void BtnCancelarEditarCadastroFuncionario_Click(object sender, EventArgs e)
        {
            txtMatriculaEditarCadastro.Text = string.Empty;
            txtNomeEditarCadastro.Text = string.Empty;
            maskCpfEditarCadastro.Text = string.Empty;
            maskDataNascimentoEditar.Text = string.Empty;
            maskTelefoneEditarCadastro.Text = string.Empty;
            txtCargoEditarCadastro.Text = string.Empty;
            txtEmailEditarCadastro.Text = string.Empty;
            txtNumeroCnhEditarCadastro.Text = string.Empty;
            txtCategoriaCnhEditarCadastro.Text = string.Empty;
            maskValidadeCnhEditarCadastro.Text = string.Empty;

            this.Close();
        }

        private void TxtMatriculaEditarCadastro_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnSalvarEditarCadastroFuncionario_Click(object sender, EventArgs e)
        {
            FuncionarioDao func = new FuncionarioDao();
            func.EditarFuncionario(Convert.ToString(txtMatriculaEditarCadastro.Text),
                Convert.ToString(txtNomeEditarCadastro.Text),
                Convert.ToString(maskCpfEditarCadastro.Text),
                Convert.ToString(maskDataNascimentoEditar.Text),
                Convert.ToString(maskTelefoneEditarCadastro.Text),
                Convert.ToString(txtCargoEditarCadastro.Text),
                Convert.ToString(txtEmailEditarCadastro.Text),
                Convert.ToString(txtNumeroCnhEditarCadastro.Text),
                Convert.ToString(txtCategoriaCnhEditarCadastro.Text),
                Convert.ToString(maskValidadeCnhEditarCadastro.Text),
                Convert.ToString(lblId.Text)
                );
        }

        private void TableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void MaskDataNascimentoEditar_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
