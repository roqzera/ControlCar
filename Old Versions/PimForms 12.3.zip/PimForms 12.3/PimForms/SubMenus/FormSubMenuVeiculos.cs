﻿using PimForms.Formulários;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PimForms.SubMenus
{
    public partial class FormSubMenuVeiculos : Form
    {
        public FormSubMenuVeiculos()
        {
            InitializeComponent();
        }

        Formularios form = new Formularios();

        public void MudaCorDaFonte(Button button1, Button button2)
        {
            button1.BackColor = Color.LightGray;

            button2.BackColor = Color.WhiteSmoke;
         
        }

        private void BtnCadastrarSubMenuVeiculos_Click(object sender, EventArgs e)
        {
            form.AbrirSubMenu<CadastrarVeiculo>(pnlFormularios);
            MudaCorDaFonte(btnCadastrarSubMenuVeiculos, btnConsultarSubMenuVeiculos);
        }

        private void BtnConsultarSubMenuVeiculos_Click(object sender, EventArgs e)
        {
            form.AbrirSubMenu<ListarVeiculos>(pnlFormularios);
            MudaCorDaFonte(btnConsultarSubMenuVeiculos, btnCadastrarSubMenuVeiculos);
        }
    }
}
