﻿using PimForms.Dao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PimForms.Classes
{
    class GerenciadorViagem
    {
        List<Viagem> ListaViagem;

        public void AdicionarViagem(Viagem viagem)
        {
            if (ListaViagem == null)
            {
                ListaViagem = new List<Viagem>();
            }

            ListaViagem.Add(viagem);
            ViagemDao viagemDao = new ViagemDao();
            viagemDao.AdicionarViagem(viagem);
        }
    }
}
