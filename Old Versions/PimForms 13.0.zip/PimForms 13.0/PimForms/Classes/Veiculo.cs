﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PimForms.Classes
{
    public class Veiculo
    {
        private string _placa;
        private string _numerorenavam;
        private string _marca;
        private string _modelo;
        private string _motor;
        private string _cor;
        private string _ano;
        private decimal _quilometragem;

        public string Placa
        {
            get
            {
                return _placa;
            }

            set
            {
                if (IsPlaca(value) == true)
                {
                    _placa = value;
                }
            }
        }

        public bool IsPlaca(string placa)
        {
            Regex regex = new Regex(@"^[a-zA-Z]{3}\-\d{4}$");

            if (regex.IsMatch(placa))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string NumeroRenavam
        {
            get
            {
                return _numerorenavam;
            }
            set
            {
                if (IsRenavam(value) == true)
                {
                    _numerorenavam = value;
                }
            }
        }

        public bool IsRenavam(string renavam)
        {

            Regex regex = new Regex(@"\d{11}$");

            if (regex.IsMatch(renavam))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    

        public string Marca
        {
            get
            {
                return _marca;
            }
            set
            {
                _marca = value;
            }
        }

        public string Modelo
        {
            get
            {
                return _modelo;
            }
            set
            {
                _modelo = value;
            }
        }

        public string Motor
        {
            get
            {
                return _motor;
            }
            set
            {
                _motor = value;
            }
        }

        public string Cor
        {
            get
            {
                return _cor;
            }
            set
            {
                _cor = value;
            }
        }

        public string Ano
        {
            get
            {
                return _ano;
            }
            set
            {
                _ano = value;
            }
        }

        public decimal Quilometragem
        {
            get
            {
                return _quilometragem;
            }
            set
            {
                _quilometragem = value;
            }
        }


        //Construtor
        public Veiculo(string placa, string numeroRenavam, string marca, string modelo, string motor, string cor, string ano, decimal quilometragem)
        {
            Placa = placa;
            NumeroRenavam = numeroRenavam;
            Marca = marca;
            Modelo = modelo;
            Motor = motor;
            Cor = cor;
            Ano = ano;
            Quilometragem = quilometragem;
        }
        //remover
        public Veiculo()
        {

        }
    }
}