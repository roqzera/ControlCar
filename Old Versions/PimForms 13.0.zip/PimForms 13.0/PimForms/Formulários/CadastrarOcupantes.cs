﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PimForms.Classes;

namespace PimForms.Formulários
{
    public partial class CadastrarOcupantes : Form
    {
        public CadastrarOcupantes()
        {
            InitializeComponent();
        }

        private void BtnAdicionar_Click(object sender, EventArgs e)
        {
            Ocupantes ocupantes = new Ocupantes(
                txtMatriculaMotorista.Text,
                txtMatriculaAcompanhante1.Text,
                txtMatriculaAcompanhante2.Text,
                txtMatriculaAcompanhante3.Text,
                txtMatriculaAcompanhante4.Text
                );


        }
    }
}
