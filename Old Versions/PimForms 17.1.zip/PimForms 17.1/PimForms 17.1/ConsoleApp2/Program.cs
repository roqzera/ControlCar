﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace ConsoleApp2
{
    public class Program
    {
        static void Main(string[] args)
        {
            int cont = 0;
            Teste[] testes = new Teste[3];

            do
            {
                testes[cont] = new Teste();
                testes[cont].Nome = Console.ReadLine();
                testes[cont].Matricula = Console.ReadLine();
                cont++;

            } while (cont < testes.Length);
            Console.ReadKey();
        }
    }
}
