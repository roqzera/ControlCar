﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PimForms.Classes;
using PimForms.Dao;

namespace PimForms.Formulários
{
    public partial class ListarViagem : Form
    {
        public ListarViagem()
        {
            InitializeComponent();
            Listar();
        }

        /*
        public void Listar()
        {
            FuncionarioDao funcionarioDao = new FuncionarioDao();
            int idFuncionario = Convert.ToInt32(funcionarioDao.BuscarIdFuncionario("matricula", toolStripTextBoxMatricula.Text));

            VeiculoDao veiculoDao = new VeiculoDao();
            int idVeiculo = Convert.ToInt32(veiculoDao.BuscarIdVeiculo(toolStripTextBoxPlaca.Text));

            ViagemDao viagemDao = new ViagemDao();
            dataGridListar.DataSource = viagemDao.ListarViagem(idFuncionario, idVeiculo);
        }
        */

        public void Listar()
        {
            ViagemDao viagemDao = new ViagemDao();
            //strMysql armazena o retorno do método BuscarFuncionario(), que é uma string de comando MySql. 
            string strMysql = viagemDao.ListarViagens();
            // A string strMysql é passada por parâmetro para que o método ExibirNoDataGridView() possa fazer a conexão com o banco e exibir os dados buscados no DataGridView
            dataGridListar.DataSource = viagemDao.ExibirNoDataGridView(strMysql);
            //dataGridListar.Columns["id_funcionario"].Visible = false;
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            Listar();
        }
    }
}
