﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;

namespace PimForms.Classes
{
    class VeiculoGerenciador
    {
        MySqlCommand cmd = new MySqlCommand();
        ConexaoBanco conexao = new ConexaoBanco();
        List<Veiculo> ListaVeiculos;

        public void AdicionarVeiculo (Veiculo veiculo)
        {
            if (ListaVeiculos == null)
            {
                ListaVeiculos = new List<Veiculo>();
            }

            ListaVeiculos.Add(veiculo);
            
        }

    }
}
