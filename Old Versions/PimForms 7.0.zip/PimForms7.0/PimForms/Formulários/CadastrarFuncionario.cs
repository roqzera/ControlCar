﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PimForms.Classes;
using PimForms.SubMenus;

namespace PimForms.Formulários
{
    public partial class CadastrarFuncionario : Form
    {
        Formularios form = new Formularios();

        public CadastrarFuncionario()
        {           
            InitializeComponent();
        }

        private void CadastrarFuncionario_Load(object sender, EventArgs e)
        {

        }

        private void BtnAdicionar_Click(object sender, EventArgs e)
        {
            Funcionario funcionario = new Funcionario(txtMatricula.Text,
                txtNome.Text,
                maskCPF.Text,
                maskDataNascimento.Text,
                maskTelefone.Text,
                txtCargo.Text,
                txtEmail.Text,
                txtNumeroCNH.Text,
                txtCategoriaCNH.Text,
                maskValidadeCNH.Text
                );

            GerenciadorFuncionario gerenciadorFuncionario = new GerenciadorFuncionario();
            gerenciadorFuncionario.AdicionarFuncionario(funcionario);

            Validacao(funcionario);

            if(funcionario.Matricula != null
                && funcionario.Nome != null
                && funcionario.CPF != null
                && funcionario.DataDeNascimento != null
                && funcionario.Telefone != null
                && funcionario.Cargo != null
                && funcionario.Email != null
                && funcionario.NumeroCNH != null
                && funcionario.CategoriaCNH != null
                && funcionario.ValidadeCNH != null
                )
            {
                labeltesteErro.Text = string.Empty;
                LimparTextBox();
            }
        }

        public void Validacao(Funcionario funcionario)
        {
            if (funcionario.IsMatricula(txtMatricula.Text) == false)
            {
                labeltesteErro.Text = "* Matrícula inválida. O campo Matrícula deve ter 5 caracteres";
                txtMatricula.Text = string.Empty;
            }
            else
            {
                if (funcionario.IsNome(txtNome.Text) == false)
                {
                    labeltesteErro.Text = "* Nome inválido. O campo Nome deve ter de 10 a 100 caracteres";
                    txtNome.Text = string.Empty;
                }
                else
                {
                    if (funcionario.IsCargo(txtCargo.Text) == false)
                    {
                        labeltesteErro.Text = "* Cargo inválido. O campo Cargo deve ter de 10 a 100 caracteres";
                        txtCargo.Text = string.Empty;
                    }
                    else
                    {
                        if (funcionario.IsEmail(txtEmail.Text) == false)
                        {
                            labeltesteErro.Text = "* Email inválido. O campo Email deve ter de 10 a 100 caracteres";
                            txtEmail.Text = string.Empty;
                        }
                        else
                        {
                            if (funcionario.IsCategoriaCNH(txtCategoriaCNH.Text) == false)
                            {
                                labeltesteErro.Text = "* Categoria da CNH inválida. O campo Categoria da CNH deve ter no máximo 2 caracteres";
                                txtCategoriaCNH.Text = string.Empty;
                            }
                        }
                    }
                }
            }
        }

        public void LimparTextBox()
        {
            txtMatricula.Text = string.Empty;
            txtNome.Text = string.Empty;
            maskCPF.Text = string.Empty;
            maskDataNascimento.Text = string.Empty;
            maskTelefone.Text = string.Empty;
            txtCargo.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtNumeroCNH.Text = string.Empty;
            txtCategoriaCNH.Text = string.Empty;
            maskValidadeCNH.Text = string.Empty;
        }

        private void TxtMatricula_MouseClick(object sender, MouseEventArgs e)
        {
            labeltesteErro.Text = string.Empty;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            LimparTextBox();
            labeltesteErro.Text = string.Empty;
        }

        private void TxtNome_MouseClick(object sender, MouseEventArgs e)
        {
            labeltesteErro.Text = string.Empty;
        }

        private void TxtCargo_MouseClick(object sender, MouseEventArgs e)
        {
            labeltesteErro.Text = string.Empty;
        }

        private void TxtEmail_MouseClick(object sender, MouseEventArgs e)
        {
            labeltesteErro.Text = string.Empty;
        }
    }
}
