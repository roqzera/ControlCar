﻿namespace PimForms.Formulários
{
    partial class EditarCadastroFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatriculaEditarCadastro = new System.Windows.Forms.TextBox();
            this.txtNomeEditarCadastro = new System.Windows.Forms.TextBox();
            this.txtNumeroCnhEditarCadastro = new System.Windows.Forms.TextBox();
            this.txtCategoriaCnhEditarCadastro = new System.Windows.Forms.TextBox();
            this.txtCargoEditarCadastro = new System.Windows.Forms.TextBox();
            this.txtEmailEditarCadastro = new System.Windows.Forms.TextBox();
            this.maskCpfEditarCadastro = new System.Windows.Forms.MaskedTextBox();
            this.maskDataNascimentoEditar = new System.Windows.Forms.MaskedTextBox();
            this.maskTelefoneEditarCadastro = new System.Windows.Forms.MaskedTextBox();
            this.maskValidadeCnhEditarCadastro = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btnSalvarEditarCadastroFuncionario = new System.Windows.Forms.Button();
            this.btnFecharEditarCadastroFuncionario = new System.Windows.Forms.Button();
            this.lblId = new System.Windows.Forms.Label();
            this.lblTituloForm = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMatriculaEditarCadastro
            // 
            this.txtMatriculaEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMatriculaEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatriculaEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.txtMatriculaEditarCadastro.Location = new System.Drawing.Point(64, 71);
            this.txtMatriculaEditarCadastro.Margin = new System.Windows.Forms.Padding(2);
            this.txtMatriculaEditarCadastro.Name = "txtMatriculaEditarCadastro";
            this.txtMatriculaEditarCadastro.ReadOnly = true;
            this.txtMatriculaEditarCadastro.Size = new System.Drawing.Size(352, 24);
            this.txtMatriculaEditarCadastro.TabIndex = 0;
            this.txtMatriculaEditarCadastro.TextChanged += new System.EventHandler(this.TxtMatriculaEditarCadastro_TextChanged);
            // 
            // txtNomeEditarCadastro
            // 
            this.txtNomeEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNomeEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.txtNomeEditarCadastro.Location = new System.Drawing.Point(64, 135);
            this.txtNomeEditarCadastro.Margin = new System.Windows.Forms.Padding(2);
            this.txtNomeEditarCadastro.Name = "txtNomeEditarCadastro";
            this.txtNomeEditarCadastro.Size = new System.Drawing.Size(352, 24);
            this.txtNomeEditarCadastro.TabIndex = 1;
            // 
            // txtNumeroCnhEditarCadastro
            // 
            this.txtNumeroCnhEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNumeroCnhEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumeroCnhEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.txtNumeroCnhEditarCadastro.Location = new System.Drawing.Point(482, 199);
            this.txtNumeroCnhEditarCadastro.Margin = new System.Windows.Forms.Padding(2);
            this.txtNumeroCnhEditarCadastro.Name = "txtNumeroCnhEditarCadastro";
            this.txtNumeroCnhEditarCadastro.Size = new System.Drawing.Size(352, 24);
            this.txtNumeroCnhEditarCadastro.TabIndex = 7;
            // 
            // txtCategoriaCnhEditarCadastro
            // 
            this.txtCategoriaCnhEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCategoriaCnhEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCategoriaCnhEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.txtCategoriaCnhEditarCadastro.Location = new System.Drawing.Point(482, 263);
            this.txtCategoriaCnhEditarCadastro.Margin = new System.Windows.Forms.Padding(2);
            this.txtCategoriaCnhEditarCadastro.Name = "txtCategoriaCnhEditarCadastro";
            this.txtCategoriaCnhEditarCadastro.Size = new System.Drawing.Size(352, 24);
            this.txtCategoriaCnhEditarCadastro.TabIndex = 8;
            // 
            // txtCargoEditarCadastro
            // 
            this.txtCargoEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCargoEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCargoEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.txtCargoEditarCadastro.Location = new System.Drawing.Point(482, 71);
            this.txtCargoEditarCadastro.Margin = new System.Windows.Forms.Padding(2);
            this.txtCargoEditarCadastro.Name = "txtCargoEditarCadastro";
            this.txtCargoEditarCadastro.Size = new System.Drawing.Size(352, 24);
            this.txtCargoEditarCadastro.TabIndex = 5;
            // 
            // txtEmailEditarCadastro
            // 
            this.txtEmailEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmailEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.txtEmailEditarCadastro.Location = new System.Drawing.Point(482, 135);
            this.txtEmailEditarCadastro.Margin = new System.Windows.Forms.Padding(2);
            this.txtEmailEditarCadastro.Name = "txtEmailEditarCadastro";
            this.txtEmailEditarCadastro.Size = new System.Drawing.Size(352, 24);
            this.txtEmailEditarCadastro.TabIndex = 6;
            // 
            // maskCpfEditarCadastro
            // 
            this.maskCpfEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.maskCpfEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskCpfEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.maskCpfEditarCadastro.Location = new System.Drawing.Point(65, 200);
            this.maskCpfEditarCadastro.Mask = "000 , 000 , 000 - 00 ";
            this.maskCpfEditarCadastro.Name = "maskCpfEditarCadastro";
            this.maskCpfEditarCadastro.Size = new System.Drawing.Size(350, 24);
            this.maskCpfEditarCadastro.TabIndex = 2;
            // 
            // maskDataNascimentoEditar
            // 
            this.maskDataNascimentoEditar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.maskDataNascimentoEditar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskDataNascimentoEditar.ForeColor = System.Drawing.Color.DimGray;
            this.maskDataNascimentoEditar.Location = new System.Drawing.Point(65, 264);
            this.maskDataNascimentoEditar.Mask = "00 / 00 / 0000";
            this.maskDataNascimentoEditar.Name = "maskDataNascimentoEditar";
            this.maskDataNascimentoEditar.Size = new System.Drawing.Size(350, 24);
            this.maskDataNascimentoEditar.TabIndex = 3;
            this.maskDataNascimentoEditar.ValidatingType = typeof(System.DateTime);
            // 
            // maskTelefoneEditarCadastro
            // 
            this.maskTelefoneEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.maskTelefoneEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskTelefoneEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.maskTelefoneEditarCadastro.Location = new System.Drawing.Point(65, 328);
            this.maskTelefoneEditarCadastro.Mask = "( 00 ) 0000 - 0000";
            this.maskTelefoneEditarCadastro.Name = "maskTelefoneEditarCadastro";
            this.maskTelefoneEditarCadastro.Size = new System.Drawing.Size(350, 24);
            this.maskTelefoneEditarCadastro.TabIndex = 4;
            // 
            // maskValidadeCnhEditarCadastro
            // 
            this.maskValidadeCnhEditarCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.maskValidadeCnhEditarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskValidadeCnhEditarCadastro.ForeColor = System.Drawing.Color.DimGray;
            this.maskValidadeCnhEditarCadastro.Location = new System.Drawing.Point(483, 328);
            this.maskValidadeCnhEditarCadastro.Mask = "00 / 00 / 0000";
            this.maskValidadeCnhEditarCadastro.Name = "maskValidadeCnhEditarCadastro";
            this.maskValidadeCnhEditarCadastro.Size = new System.Drawing.Size(350, 24);
            this.maskValidadeCnhEditarCadastro.TabIndex = 9;
            this.maskValidadeCnhEditarCadastro.ValidatingType = typeof(System.DateTime);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(62, 37);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(356, 32);
            this.label1.TabIndex = 33;
            this.label1.Text = "Matrícula";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(62, 165);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(356, 32);
            this.label3.TabIndex = 35;
            this.label3.Text = "CPF";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(62, 229);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(356, 32);
            this.label4.TabIndex = 36;
            this.label4.Text = "Data de Nascimento";
            this.label4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(62, 293);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(356, 32);
            this.label5.TabIndex = 37;
            this.label5.Text = "Telefone";
            this.label5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(480, 37);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(356, 32);
            this.label6.TabIndex = 38;
            this.label6.Text = "Cargo";
            this.label6.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(480, 101);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(356, 32);
            this.label7.TabIndex = 39;
            this.label7.Text = "E-mail";
            this.label7.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(480, 165);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(356, 32);
            this.label8.TabIndex = 40;
            this.label8.Text = "Número da CNH";
            this.label8.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(480, 229);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(356, 32);
            this.label9.TabIndex = 41;
            this.label9.Text = "Categoria da CNH";
            this.label9.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.931329F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.55844F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.941231F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.63768F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.931329F));
            this.tableLayoutPanel1.Controls.Add(this.txtMatriculaEditarCadastro, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtNomeEditarCadastro, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtNumeroCnhEditarCadastro, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtCategoriaCnhEditarCadastro, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.txtCargoEditarCadastro, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtEmailEditarCadastro, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.maskCpfEditarCadastro, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.maskDataNascimentoEditar, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.maskTelefoneEditarCadastro, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.maskValidadeCnhEditarCadastro, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label4, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.label5, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.label6, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.label7, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.label8, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.label9, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.label10, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.btnSalvarEditarCadastroFuncionario, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.btnFecharEditarCadastroFuncionario, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.lblId, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 32);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.083411F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.005459F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.360761F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.50123F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(900, 468);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(62, 101);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(356, 32);
            this.label2.TabIndex = 34;
            this.label2.Text = "Nome";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DimGray;
            this.label10.Location = new System.Drawing.Point(480, 293);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(356, 32);
            this.label10.TabIndex = 42;
            this.label10.Text = "Validade da CNH";
            this.label10.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // btnSalvarEditarCadastroFuncionario
            // 
            this.btnSalvarEditarCadastroFuncionario.BackColor = System.Drawing.Color.Gray;
            this.btnSalvarEditarCadastroFuncionario.FlatAppearance.BorderSize = 0;
            this.btnSalvarEditarCadastroFuncionario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btnSalvarEditarCadastroFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvarEditarCadastroFuncionario.ForeColor = System.Drawing.Color.White;
            this.btnSalvarEditarCadastroFuncionario.Image = global::PimForms.Properties.Resources.icone_confirmar_20x20;
            this.btnSalvarEditarCadastroFuncionario.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalvarEditarCadastroFuncionario.Location = new System.Drawing.Point(480, 396);
            this.btnSalvarEditarCadastroFuncionario.Margin = new System.Windows.Forms.Padding(0);
            this.btnSalvarEditarCadastroFuncionario.Name = "btnSalvarEditarCadastroFuncionario";
            this.btnSalvarEditarCadastroFuncionario.Size = new System.Drawing.Size(100, 30);
            this.btnSalvarEditarCadastroFuncionario.TabIndex = 10;
            this.btnSalvarEditarCadastroFuncionario.Text = "       Salvar";
            this.btnSalvarEditarCadastroFuncionario.UseVisualStyleBackColor = false;
            this.btnSalvarEditarCadastroFuncionario.Click += new System.EventHandler(this.BtnSalvarEditarCadastroFuncionario_Click);
            // 
            // btnFecharEditarCadastroFuncionario
            // 
            this.btnFecharEditarCadastroFuncionario.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFecharEditarCadastroFuncionario.BackColor = System.Drawing.Color.Gray;
            this.btnFecharEditarCadastroFuncionario.FlatAppearance.BorderSize = 0;
            this.btnFecharEditarCadastroFuncionario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btnFecharEditarCadastroFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFecharEditarCadastroFuncionario.ForeColor = System.Drawing.Color.White;
            this.btnFecharEditarCadastroFuncionario.Image = global::PimForms.Properties.Resources.icone_cancelar_20x20;
            this.btnFecharEditarCadastroFuncionario.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFecharEditarCadastroFuncionario.Location = new System.Drawing.Point(318, 396);
            this.btnFecharEditarCadastroFuncionario.Margin = new System.Windows.Forms.Padding(0);
            this.btnFecharEditarCadastroFuncionario.Name = "btnFecharEditarCadastroFuncionario";
            this.btnFecharEditarCadastroFuncionario.Size = new System.Drawing.Size(100, 30);
            this.btnFecharEditarCadastroFuncionario.TabIndex = 11;
            this.btnFecharEditarCadastroFuncionario.Text = "       Fechar";
            this.btnFecharEditarCadastroFuncionario.UseVisualStyleBackColor = false;
            this.btnFecharEditarCadastroFuncionario.Click += new System.EventHandler(this.BtnCancelarEditarCadastroFuncionario_Click);
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(3, 0);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(7, 13);
            this.lblId.TabIndex = 44;
            this.lblId.Text = "\r\n";
            this.lblId.Visible = false;
            // 
            // lblTituloForm
            // 
            this.lblTituloForm.BackColor = System.Drawing.Color.Gray;
            this.lblTituloForm.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTituloForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloForm.ForeColor = System.Drawing.Color.White;
            this.lblTituloForm.Location = new System.Drawing.Point(0, 0);
            this.lblTituloForm.Margin = new System.Windows.Forms.Padding(0);
            this.lblTituloForm.Name = "lblTituloForm";
            this.lblTituloForm.Size = new System.Drawing.Size(900, 32);
            this.lblTituloForm.TabIndex = 3;
            this.lblTituloForm.Text = "Editar Cadastro ";
            this.lblTituloForm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EditarCadastroFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 500);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.lblTituloForm);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EditarCadastroFuncionario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditarCadastroFuncionario";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnSalvarEditarCadastroFuncionario;
        private System.Windows.Forms.Button btnFecharEditarCadastroFuncionario;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label lblTituloForm;
        public System.Windows.Forms.TextBox txtMatriculaEditarCadastro;
        public System.Windows.Forms.TextBox txtNomeEditarCadastro;
        public System.Windows.Forms.TextBox txtNumeroCnhEditarCadastro;
        public System.Windows.Forms.TextBox txtCategoriaCnhEditarCadastro;
        public System.Windows.Forms.TextBox txtCargoEditarCadastro;
        public System.Windows.Forms.TextBox txtEmailEditarCadastro;
        public System.Windows.Forms.MaskedTextBox maskCpfEditarCadastro;
        public System.Windows.Forms.MaskedTextBox maskDataNascimentoEditar;
        public System.Windows.Forms.MaskedTextBox maskTelefoneEditarCadastro;
        public System.Windows.Forms.MaskedTextBox maskValidadeCnhEditarCadastro;
        public System.Windows.Forms.Label lblId;
    }
}