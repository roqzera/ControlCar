﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;

namespace PimForms.Classes
{
    class VeiculoGerenciador
    {
        MySqlCommand cmd = new MySqlCommand();
        ConexaoBanco conexao = new ConexaoBanco();

        public void AdicionarVeiculo (Veiculo veiculo)
        {
            //Comando Sql: insert, update, delete

            cmd.CommandText = "INSERT INTO VEICULOS (placa, numero_renavam, marca, modelo, motor, cor, ano, quilometragem) " +
                "VALUES (@Placa, @NumeroRenavam, @Marca, @Modelo, @Motor, @Cor, @Ano, @Quilometragem)";

            //Parametros

            cmd.Parameters.AddWithValue("@Placa", veiculo.Placa);
            cmd.Parameters.AddWithValue("@NumeroRenavam", veiculo.NumeroRenavam);
            cmd.Parameters.AddWithValue("@Marca", veiculo.Marca);
            cmd.Parameters.AddWithValue("@Modelo", veiculo.Modelo);
            cmd.Parameters.AddWithValue("@Motor", veiculo.Motor);
            cmd.Parameters.AddWithValue("@Cor", veiculo.Cor);
            cmd.Parameters.AddWithValue("@Ano", veiculo.Ano);
            cmd.Parameters.AddWithValue("@Quilometragem", veiculo.Quilometragem);



            try
            {
                //Conectar com o banco
                cmd.Connection = conexao.Conectar();
                //Executar Comando
                cmd.ExecuteNonQuery();
                //Desconectar
                conexao.Desconectar();
                //Mostrar mensagem de sucesso/erro
                MessageBox.Show("Cadastrado com Sucesso");
            }

            catch (MySqlException e)
            {
                MessageBox.Show("Erro ao tentar se conectar com o banco de dados");
            }

        }

        public DataTable Listar()
        {

            MySqlCommand cmd = new MySqlCommand();
            ConexaoBanco conexao = new ConexaoBanco();

            try
            {
                MySqlConnection mySqlConnection;
                mySqlConnection = conexao.Conectar();
                string strCon = "SELECT * FROM veiculos";
                // cmd.CommandText = "SELECT * FROM funcionario";
                cmd = new MySqlCommand(strCon, mySqlConnection);

                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter();
                // Seleciona os dados do banco e preenche o DataAdapter com esses dados
                mySqlDataAdapter.SelectCommand = cmd;

                DataTable dataTable = new DataTable();
                // Armazena no DataTable os dados que foram buscados no banco com o uso do SelectCommand
                mySqlDataAdapter.Fill(dataTable);

                return dataTable;
            }

            catch (MySqlException ex)
            {
                throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }

        }


    }
}
