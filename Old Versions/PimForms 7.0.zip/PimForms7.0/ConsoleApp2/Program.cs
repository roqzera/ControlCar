﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class Program
    {
        static void Main(string[] args)
        {
            Teste teste = new Teste();
            teste.Matricula = "354343";

            Console.WriteLine($"Mtrícula: {teste.Matricula}");
            Console.ReadKey();
        }
    }
}
