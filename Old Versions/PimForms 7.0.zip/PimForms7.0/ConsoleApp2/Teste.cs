﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class Teste
    {
        private string _matricula;

        public string Matricula
        {
            get { return _matricula; }
            set
            {
                if(IsValido(value) == true)
                _matricula = value;
            }
        }

        public bool IsValido(string matricula)
        {
            bool valido = true;

            if (matricula.Length > 5)
            {
                valido = false;
            }

            return valido;
        }

    }
}
