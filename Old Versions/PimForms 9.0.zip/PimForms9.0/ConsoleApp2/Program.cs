﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Teste teste = new Teste();
            ValidaDataDeNascimento validaDataDeNascimento = new ValidaDataDeNascimento();
            char resposta;

            do
            {
                Console.Write("Insira uma data dd/mm/yyyy: ");
                //string data = "23/02/2000";
                DateTime dateTime = Convert.ToDateTime(Console.ReadLine());

                //DateTime novaData = Convert.ToDateTime(data);

                //Console.WriteLine(data);
                //Console.WriteLine(data.GetType());

                //Console.WriteLine(novaData);
                //Console.WriteLine(novaData.GetType());

                //string data = Convert.ToString(dateTime);
                //// remove as barras, ficando somentes os números
                //data = data.Replace("/", "");
                ////Console.WriteLine(data);

                //// dia
                //Console.WriteLine("\n------- Dia ---------");
                //Console.WriteLine("Dia: {0}", dia);

                //// mês
                //Console.WriteLine("\n------- Mês ---------");
                //Console.WriteLine("Mês: {0}", mes);
                //Console.WriteLine("Quantidade de dias do mês: {0}", teste.QuantidadeDeDiasDoMes(ano, mes));

                //// ano
                //Console.WriteLine("\n------- Ano ---------");
                //Console.WriteLine("Ano: {0}", ano);
                //Console.WriteLine("Ano bissexto: " + teste.IsAnoBissexto(teste.ConverteAno(ano)));

                Console.WriteLine();
                //teste.IsData(ano, mes);
                if (validaDataDeNascimento.IsDataDeNascimento(dateTime) == true)
                {
                    Console.WriteLine("Data válida");
                }
                else
                {
                    Console.WriteLine("Data inválida");
                }

                Console.WriteLine();
                Console.WriteLine("Data de Nascimento: {0}", validaDataDeNascimento._dataDeNascimento);
                Console.WriteLine();

                Console.Write("\nDeseja verificar a validação de outra data? [S/n] ");
                resposta = Convert.ToChar(Console.ReadLine());
                Console.Clear();

            } while (resposta == 'S' || resposta == 's');

            Console.ReadKey();
        }
    }
}
