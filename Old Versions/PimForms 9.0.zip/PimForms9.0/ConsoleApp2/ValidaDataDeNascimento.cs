﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class ValidaDataDeNascimento
    {
        private DateTime _dataDeNascimento;

        public DateTime DataDeNascimento
        {
            get { return _dataDeNascimento; }
            set
            {
                if(IsDataDeNascimento(value) == true)
                {
                    _dataDeNascimento = value;
                }
            }
        }

        public bool IsDataDeNascimento(DateTime dateTime)
        {
            string data = Convert.ToString(dateTime);
            // remove as barras, espaços e dois pontos, ficando somentes os números
            data = data.Replace("/", "").Replace(" ", "").Replace(":", "");
            //Console.WriteLine(data);

            // Manipula a string data extraindo separadamente dia, mês e ano
            string dia = data.Substring(0).Remove(2, 12);
            string mes = data.Substring(0).Remove(0, 2).Substring(0).Remove(2, 10);
            string ano = data.Substring(0).Remove(0, 4).Substring(0).Remove(3, 6);

            Teste teste = new Teste();

            if ((teste.IsDataMesFevereiro(ano, mes, dia) || teste.IsDataComMesDe30Dias(ano, mes, dia) || teste.IsDataComMesDe31Dias(ano, mes, dia)) == true)
            {
                //Convert.ToString(ano);
                //Convert.ToString(mes);
                //Convert.ToString(dia);
                //dateTime = Convert.ToDateTime(dia + "/" + mes + "/" + ano + " 00:00:00");
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
