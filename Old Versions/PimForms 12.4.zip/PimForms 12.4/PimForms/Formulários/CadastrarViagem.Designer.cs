﻿namespace PimForms.Formulários
{
    partial class CadastrarViagem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxPlaca = new System.Windows.Forms.TextBox();
            this.tbxKmInicial = new System.Windows.Forms.TextBox();
            this.maskValorAdiantamento = new System.Windows.Forms.MaskedTextBox();
            this.lblPlacaVeiculo = new System.Windows.Forms.Label();
            this.lblDestino = new System.Windows.Forms.Label();
            this.lblValorAdiantamento = new System.Windows.Forms.Label();
            this.lblCargo = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblKmInicial = new System.Windows.Forms.Label();
            this.lblKmFinal = new System.Windows.Forms.Label();
            this.labeltesteErro = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnAdicionar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.maskedDataSaida = new System.Windows.Forms.MaskedTextBox();
            this.maskedDataRetorno = new System.Windows.Forms.MaskedTextBox();
            this.tbxKmFinal = new System.Windows.Forms.TextBox();
            this.lblQuantidadeAcompanhantes = new System.Windows.Forms.Label();
            this.tbxQtdOcupantes = new System.Windows.Forms.TextBox();
            this.tbxDestino = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblTituloForm = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbxPlaca
            // 
            this.tbxPlaca.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxPlaca.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.tbxPlaca.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tbxPlaca.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxPlaca.ForeColor = System.Drawing.Color.DimGray;
            this.tbxPlaca.Location = new System.Drawing.Point(46, 131);
            this.tbxPlaca.Margin = new System.Windows.Forms.Padding(2);
            this.tbxPlaca.Name = "tbxPlaca";
            this.tbxPlaca.Size = new System.Drawing.Size(249, 24);
            this.tbxPlaca.TabIndex = 1;
            this.tbxPlaca.TextChanged += new System.EventHandler(this.TbxPlaca_TextChanged);
            // 
            // tbxKmInicial
            // 
            this.tbxKmInicial.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxKmInicial.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxKmInicial.ForeColor = System.Drawing.Color.DimGray;
            this.tbxKmInicial.Location = new System.Drawing.Point(343, 131);
            this.tbxKmInicial.Margin = new System.Windows.Forms.Padding(2);
            this.tbxKmInicial.Name = "tbxKmInicial";
            this.tbxKmInicial.Size = new System.Drawing.Size(249, 24);
            this.tbxKmInicial.TabIndex = 7;
            // 
            // maskValorAdiantamento
            // 
            this.maskValorAdiantamento.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.maskValorAdiantamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskValorAdiantamento.ForeColor = System.Drawing.Color.DimGray;
            this.maskValorAdiantamento.Location = new System.Drawing.Point(47, 216);
            this.maskValorAdiantamento.Name = "maskValorAdiantamento";
            this.maskValorAdiantamento.Size = new System.Drawing.Size(247, 24);
            this.maskValorAdiantamento.TabIndex = 4;
            // 
            // lblPlacaVeiculo
            // 
            this.lblPlacaVeiculo.AutoSize = true;
            this.lblPlacaVeiculo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPlacaVeiculo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlacaVeiculo.ForeColor = System.Drawing.Color.DimGray;
            this.lblPlacaVeiculo.Location = new System.Drawing.Point(44, 108);
            this.lblPlacaVeiculo.Margin = new System.Windows.Forms.Padding(0);
            this.lblPlacaVeiculo.Name = "lblPlacaVeiculo";
            this.lblPlacaVeiculo.Size = new System.Drawing.Size(253, 21);
            this.lblPlacaVeiculo.TabIndex = 34;
            this.lblPlacaVeiculo.Text = "Placa do Veículo";
            this.lblPlacaVeiculo.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblDestino
            // 
            this.lblDestino.AutoSize = true;
            this.lblDestino.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDestino.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDestino.ForeColor = System.Drawing.Color.DimGray;
            this.lblDestino.Location = new System.Drawing.Point(44, 150);
            this.lblDestino.Margin = new System.Windows.Forms.Padding(0);
            this.lblDestino.Name = "lblDestino";
            this.lblDestino.Size = new System.Drawing.Size(253, 21);
            this.lblDestino.TabIndex = 35;
            this.lblDestino.Text = "Destino";
            this.lblDestino.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblValorAdiantamento
            // 
            this.lblValorAdiantamento.AutoSize = true;
            this.lblValorAdiantamento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblValorAdiantamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorAdiantamento.ForeColor = System.Drawing.Color.DimGray;
            this.lblValorAdiantamento.Location = new System.Drawing.Point(44, 192);
            this.lblValorAdiantamento.Margin = new System.Windows.Forms.Padding(0);
            this.lblValorAdiantamento.Name = "lblValorAdiantamento";
            this.lblValorAdiantamento.Size = new System.Drawing.Size(253, 21);
            this.lblValorAdiantamento.TabIndex = 37;
            this.lblValorAdiantamento.Text = "Valor do Adiantamento";
            this.lblValorAdiantamento.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCargo.ForeColor = System.Drawing.Color.DimGray;
            this.lblCargo.Location = new System.Drawing.Point(341, 26);
            this.lblCargo.Margin = new System.Windows.Forms.Padding(0);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(253, 19);
            this.lblCargo.TabIndex = 38;
            this.lblCargo.Text = "Data Saída";
            this.lblCargo.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.ForeColor = System.Drawing.Color.DimGray;
            this.lblEmail.Location = new System.Drawing.Point(341, 66);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(253, 21);
            this.lblEmail.TabIndex = 39;
            this.lblEmail.Text = "Data Retorno";
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblKmInicial
            // 
            this.lblKmInicial.AutoSize = true;
            this.lblKmInicial.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblKmInicial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKmInicial.ForeColor = System.Drawing.Color.DimGray;
            this.lblKmInicial.Location = new System.Drawing.Point(341, 108);
            this.lblKmInicial.Margin = new System.Windows.Forms.Padding(0);
            this.lblKmInicial.Name = "lblKmInicial";
            this.lblKmInicial.Size = new System.Drawing.Size(253, 21);
            this.lblKmInicial.TabIndex = 40;
            this.lblKmInicial.Text = "KM Inicial";
            this.lblKmInicial.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblKmFinal
            // 
            this.lblKmFinal.AutoSize = true;
            this.lblKmFinal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblKmFinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKmFinal.ForeColor = System.Drawing.Color.DimGray;
            this.lblKmFinal.Location = new System.Drawing.Point(341, 150);
            this.lblKmFinal.Margin = new System.Windows.Forms.Padding(0);
            this.lblKmFinal.Name = "lblKmFinal";
            this.lblKmFinal.Size = new System.Drawing.Size(253, 21);
            this.lblKmFinal.TabIndex = 41;
            this.lblKmFinal.Text = "KM Final";
            this.lblKmFinal.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // labeltesteErro
            // 
            this.labeltesteErro.AutoSize = true;
            this.labeltesteErro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labeltesteErro.ForeColor = System.Drawing.Color.Red;
            this.labeltesteErro.Location = new System.Drawing.Point(47, 234);
            this.labeltesteErro.Name = "labeltesteErro";
            this.labeltesteErro.Size = new System.Drawing.Size(247, 25);
            this.labeltesteErro.TabIndex = 44;
            this.labeltesteErro.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.931329F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.55844F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.941231F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.63768F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.931329F));
            this.tableLayoutPanel1.Controls.Add(this.tbxKmInicial, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblCargo, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblEmail, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblKmInicial, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblKmFinal, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.btnAdicionar, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.button1, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.labeltesteErro, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.maskedDataSaida, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.maskedDataRetorno, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.tbxKmFinal, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.lblQuantidadeAcompanhantes, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.tbxQtdOcupantes, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.maskValorAdiantamento, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.lblValorAdiantamento, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.tbxDestino, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.lblDestino, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.tbxPlaca, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblPlacaVeiculo, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox1, 1, 4);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 32);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.441559F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.168831F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.00546F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.005459F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.360761F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.50123F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(640, 308);
            this.tableLayoutPanel1.TabIndex = 4;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.TableLayoutPanel1_Paint);
            // 
            // btnAdicionar
            // 
            this.btnAdicionar.BackColor = System.Drawing.Color.Gray;
            this.btnAdicionar.FlatAppearance.BorderSize = 0;
            this.btnAdicionar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btnAdicionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdicionar.ForeColor = System.Drawing.Color.White;
            this.btnAdicionar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdicionar.Location = new System.Drawing.Point(341, 259);
            this.btnAdicionar.Margin = new System.Windows.Forms.Padding(0);
            this.btnAdicionar.Name = "btnAdicionar";
            this.btnAdicionar.Size = new System.Drawing.Size(100, 30);
            this.btnAdicionar.TabIndex = 11;
            this.btnAdicionar.Text = "       Adicionar";
            this.btnAdicionar.UseVisualStyleBackColor = false;
            this.btnAdicionar.Click += new System.EventHandler(this.BtnAdicionar_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.Gray;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(197, 259);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 30);
            this.button1.TabIndex = 12;
            this.button1.Text = "       Cancelar";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // maskedDataSaida
            // 
            this.maskedDataSaida.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.maskedDataSaida.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedDataSaida.ForeColor = System.Drawing.Color.DimGray;
            this.maskedDataSaida.Location = new System.Drawing.Point(344, 48);
            this.maskedDataSaida.Mask = "00/00/0000";
            this.maskedDataSaida.Name = "maskedDataSaida";
            this.maskedDataSaida.Size = new System.Drawing.Size(247, 24);
            this.maskedDataSaida.TabIndex = 48;
            this.maskedDataSaida.ValidatingType = typeof(System.DateTime);
            this.maskedDataSaida.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedDataSaida_MaskInputRejected);
            // 
            // maskedDataRetorno
            // 
            this.maskedDataRetorno.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.maskedDataRetorno.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedDataRetorno.ForeColor = System.Drawing.Color.DimGray;
            this.maskedDataRetorno.Location = new System.Drawing.Point(344, 90);
            this.maskedDataRetorno.Mask = "00/00/0000";
            this.maskedDataRetorno.Name = "maskedDataRetorno";
            this.maskedDataRetorno.Size = new System.Drawing.Size(247, 24);
            this.maskedDataRetorno.TabIndex = 49;
            this.maskedDataRetorno.ValidatingType = typeof(System.DateTime);
            // 
            // tbxKmFinal
            // 
            this.tbxKmFinal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxKmFinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxKmFinal.ForeColor = System.Drawing.Color.DimGray;
            this.tbxKmFinal.Location = new System.Drawing.Point(343, 173);
            this.tbxKmFinal.Margin = new System.Windows.Forms.Padding(2);
            this.tbxKmFinal.Name = "tbxKmFinal";
            this.tbxKmFinal.Size = new System.Drawing.Size(249, 24);
            this.tbxKmFinal.TabIndex = 50;
            // 
            // lblQuantidadeAcompanhantes
            // 
            this.lblQuantidadeAcompanhantes.AutoSize = true;
            this.lblQuantidadeAcompanhantes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblQuantidadeAcompanhantes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantidadeAcompanhantes.ForeColor = System.Drawing.Color.DimGray;
            this.lblQuantidadeAcompanhantes.Location = new System.Drawing.Point(44, 26);
            this.lblQuantidadeAcompanhantes.Margin = new System.Windows.Forms.Padding(0);
            this.lblQuantidadeAcompanhantes.Name = "lblQuantidadeAcompanhantes";
            this.lblQuantidadeAcompanhantes.Size = new System.Drawing.Size(253, 19);
            this.lblQuantidadeAcompanhantes.TabIndex = 36;
            this.lblQuantidadeAcompanhantes.Text = "Quantidade de Ocupantes";
            this.lblQuantidadeAcompanhantes.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tbxQtdOcupantes
            // 
            this.tbxQtdOcupantes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxQtdOcupantes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxQtdOcupantes.ForeColor = System.Drawing.Color.DimGray;
            this.tbxQtdOcupantes.Location = new System.Drawing.Point(46, 47);
            this.tbxQtdOcupantes.Margin = new System.Windows.Forms.Padding(2);
            this.tbxQtdOcupantes.Name = "tbxQtdOcupantes";
            this.tbxQtdOcupantes.Size = new System.Drawing.Size(249, 24);
            this.tbxQtdOcupantes.TabIndex = 47;
            // 
            // tbxDestino
            // 
            this.tbxDestino.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxDestino.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxDestino.ForeColor = System.Drawing.Color.DimGray;
            this.tbxDestino.Location = new System.Drawing.Point(46, 173);
            this.tbxDestino.Margin = new System.Windows.Forms.Padding(2);
            this.tbxDestino.Name = "tbxDestino";
            this.tbxDestino.Size = new System.Drawing.Size(249, 24);
            this.tbxDestino.TabIndex = 46;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(44, 66);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 21);
            this.label1.TabIndex = 51;
            this.label1.Text = "Matrícula do Funcionário";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.textBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.DimGray;
            this.textBox1.Location = new System.Drawing.Point(44, 87);
            this.textBox1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(253, 24);
            this.textBox1.TabIndex = 52;
            // 
            // lblTituloForm
            // 
            this.lblTituloForm.BackColor = System.Drawing.Color.Gray;
            this.lblTituloForm.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTituloForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloForm.ForeColor = System.Drawing.Color.White;
            this.lblTituloForm.Location = new System.Drawing.Point(0, 0);
            this.lblTituloForm.Margin = new System.Windows.Forms.Padding(0);
            this.lblTituloForm.Name = "lblTituloForm";
            this.lblTituloForm.Size = new System.Drawing.Size(640, 32);
            this.lblTituloForm.TabIndex = 3;
            this.lblTituloForm.Text = "Cadastrar Viagem";
            this.lblTituloForm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CadastrarViagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(640, 340);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.lblTituloForm);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CadastrarViagem";
            this.Text = "CadastrarViagem";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.CadastrarViagem_Load_1);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox tbxPlaca;
        private System.Windows.Forms.TextBox tbxKmInicial;
        private System.Windows.Forms.MaskedTextBox maskValorAdiantamento;
        private System.Windows.Forms.Label lblPlacaVeiculo;
        private System.Windows.Forms.Label lblDestino;
        private System.Windows.Forms.Label lblValorAdiantamento;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblKmInicial;
        private System.Windows.Forms.Label lblKmFinal;
        private System.Windows.Forms.Button btnAdicionar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label labeltesteErro;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox tbxDestino;
        private System.Windows.Forms.TextBox tbxQtdOcupantes;
        private System.Windows.Forms.MaskedTextBox maskedDataSaida;
        private System.Windows.Forms.MaskedTextBox maskedDataRetorno;
        private System.Windows.Forms.TextBox tbxKmFinal;
        public System.Windows.Forms.Label lblTituloForm;
        private System.Windows.Forms.Label lblQuantidadeAcompanhantes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
    }
}