﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PimForms.Classes
{
    public class Ocupantes
    {
        private string _matriculaMotorista;
        private string _matriculaAcompanhante1;
        private string _matriculaAcompanhante2;
        private string _matriculaAcompanhante3;
        private string _matriculaAcompanhante4;

        public string MatriculaMotorista
        {
            get { return _matriculaMotorista; }
            set { _matriculaMotorista = value; }
        }

        public Ocupantes(string matriculaMotorista, string matriculaAcompanhante1, string matriculaAcompanhante2, string matriculaAcompanhante3, string matriculaAcompanhante4)
        {
            MatriculaMotorista = matriculaMotorista;
            MatriculaAcompanhante1 = matriculaAcompanhante1;
            MatriculaAcompanhante2 = matriculaAcompanhante2;
            MatriculaAcompanhante3 = matriculaAcompanhante3;
            MatriculaAcompanhante4 = matriculaAcompanhante4;
            MatriculaMotorista = matriculaMotorista;
            MatriculaAcompanhante1 = matriculaAcompanhante1;
            MatriculaAcompanhante2 = matriculaAcompanhante2;
            MatriculaAcompanhante3 = matriculaAcompanhante3;
            MatriculaAcompanhante4 = matriculaAcompanhante4;
        }

        public string MatriculaAcompanhante1
        {
            get { return _matriculaAcompanhante1; }
            set { _matriculaAcompanhante1 = value; }
        }

        public string MatriculaAcompanhante2
        {
            get { return _matriculaAcompanhante2; }
            set { _matriculaAcompanhante2 = value; }
        }

        public string MatriculaAcompanhante3
        {
            get { return _matriculaAcompanhante3; }
            set { _matriculaAcompanhante3 = value; }
        }

        public string MatriculaAcompanhante4
        {
            get { return _matriculaAcompanhante4; }
            set { _matriculaAcompanhante4 = value; }
        }
    }
}
