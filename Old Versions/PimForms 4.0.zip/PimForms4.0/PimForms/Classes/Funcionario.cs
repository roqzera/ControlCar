﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PimForms
{
    public class Funcionario
    {
        private string _matricula;
        private string _nome;
        private string _cpf;
        private string _dataDeNascimento;
        private string _telefone;
        private string _cargo;
        private string _email;
        private string _numeroCNH;
        private string _categoriaCNH;
        private string _validadeCNH;

        public string Matricula
        {
            get { return _matricula; }
            set { _matricula = value; }
        }

        public string Nome
        {
            get { return _nome; }
            set { _nome = value; }
        }

        public string CPF
        {
            get { return _cpf; }
            set { _cpf = value; }
        }

        public string DataDeNascimento
        {
            get { return _dataDeNascimento; }
            set { _dataDeNascimento = value; }
        }

        public string Telefone
        {
            get { return _telefone; }
            set { _telefone = value; }
        }

        public string Cargo
        {
            get { return _cargo; }
            set { _cargo = value; }
        }

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }

        public string NumeroCNH
        {
            get { return _numeroCNH; }
            set { _numeroCNH = value; }
        }

        public string CategoriaCNH
        {
            get { return _categoriaCNH; }
            set { _categoriaCNH = value; }
        }

        public string ValidadeCNH
        {
            get { return _validadeCNH; }
            set { _validadeCNH = value; }
        }

        public Funcionario(string matricula,
            string nome,
            string cpf,
            string dataDeNascimento,
            string telefone,
            string cargo,
            string email,
            string numeroCNH,
            string categoriaCNH,
            string validadeCNH
            )
        {
            Matricula = matricula;
            Nome = nome;
            CPF = cpf;
            DataDeNascimento = dataDeNascimento;
            Telefone = telefone;
            Cargo = cargo;
            Email = email;
            NumeroCNH = numeroCNH;
            CategoriaCNH = categoriaCNH;
            ValidadeCNH = validadeCNH;
        }
    }
}
