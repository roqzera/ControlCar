﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;


namespace PimForms.Classes
{
    public class FuncionarioDao
    {
        MySqlCommand cmd = new MySqlCommand();
        ConexaoBanco conexao = new ConexaoBanco();
        MySqlConnection mySqlConnection;

        // public string StrCon { get; set; }

        public void AdicionarFuncionario(Funcionario funcionario)
        {

            cmd.CommandText = "INSERT INTO funcionario(" +
                "matricula, nome, cpf, data_nascimento, telefone, cargo, email, numero_cnh, categoria_cnh, validade_cnh)" +
                "VALUES (@matricula, @nome, @cpf, @data_nascimento, @telefone, @cargo, @email, @numero_cnh, @categoria_cnh, @validade_cnh)";

            // Cria um novo objeto do tipo MySqlCommand recebendo como parâmetro a string de acesso e o objeto de conexão. 


            cmd.Parameters.AddWithValue("@matricula", funcionario.Matricula);
            cmd.Parameters.AddWithValue("@nome", funcionario.Nome);
            cmd.Parameters.AddWithValue("@cpf", funcionario.CPF);
            cmd.Parameters.AddWithValue("@data_nascimento", funcionario.DataDeNascimento);
            cmd.Parameters.AddWithValue("@telefone", funcionario.Telefone);
            cmd.Parameters.AddWithValue("@cargo", funcionario.Cargo);
            cmd.Parameters.AddWithValue("@email", funcionario.Email);
            cmd.Parameters.AddWithValue("@numero_cnh", funcionario.NumeroCNH);
            cmd.Parameters.AddWithValue("@categoria_cnh", funcionario.CategoriaCNH);
            cmd.Parameters.AddWithValue("@validade_cnh", funcionario.ValidadeCNH);

            try
            {
                //Conectar com o banco
                cmd.Connection = conexao.Conectar();
                //Executar Comando
                cmd.ExecuteNonQuery();
                //Desconectar
                conexao.Desconectar();
                //Mostrar mensagem de sucesso/erro
                MessageBox.Show("Cadastrado com Sucesso");
            }

            catch (MySqlException ex)
            {
                MessageBox.Show("Erro ao tentar se conectar com o banco de dados");
                throw ex;
            }

        }

        public string ListarFuncionarios()
        {
            string strMysql = "SELECT matricula, nome, cpf, data_nascimento, telefone, cargo, email, numero_cnh, categoria_cnh, validade_cnh FROM funcionario";

            return strMysql;
        }

        public string BuscarFuncionario(string matricula)
        {

            string strMysql = "SELECT * FROM funcionario WHERE matricula =" + matricula;

            return strMysql;
        }

        public DataTable ExibirNoDataGridView(string strCon)
        {
            //MySqlCommand cmd = new MySqlCommand();
            //ConexaoBanco conexao = new ConexaoBanco();

            try
            {
                mySqlConnection = conexao.Conectar();
                cmd = new MySqlCommand(strCon, mySqlConnection);

                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter();
                // Seleciona os dados do banco e preenche o DataAdapter com esses dados
                mySqlDataAdapter.SelectCommand = cmd; 

                DataTable dataTable = new DataTable();
                // Armazena no DataTable os dados que foram buscados no banco com o uso do SelectCommand
                mySqlDataAdapter.Fill(dataTable);

                return dataTable;
            }

            catch (MySqlException ex)
            {
                throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }

        }
    }
}
    


