﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PimForms.Classes;
using PimForms.SubMenus;
using PimForms.Formulários;

namespace PimForms.Formulários
{
    public partial class ListarFuncionario : Form
    {
        public ListarFuncionario()
        {
            InitializeComponent();
            Listar();
        }

        Formularios form = new Formularios();

        // Método usado para listar todos os funcionários cadastrados no DataGridView assim que o form EditarCadastroFuncionario é inicializado
        public void Listar()
        {
            FuncionarioDao funcionarioDao = new FuncionarioDao();
            //strMysql armazena o retorno do método BuscarFuncionario(), que é uma string de comando MySql. 
            string strMysql = funcionarioDao.ListarFuncionarios();
            // A string strMysql é passada por parâmetro para que o método ExibirNoDataGridView() possa fazer a conexão com o banco e exibir os dados buscados no DataGridView
            dataGridListar.DataSource = funcionarioDao.ExibirNoDataGridView(strMysql);
        }

        private void ToolStripButtonPesquisar_Click(object sender, EventArgs e)
        {
            string matricula = Convert.ToString(toolStripTextBoxMatricula.Text);

            //GerenciadorFuncionario gerenciadorFuncionario = new GerenciadorFuncionario();
            //gerenciadorFuncionario.BuscarFuncionario(matricula);

            FuncionarioDao funcionarioDao = new FuncionarioDao();
            //strMysql armazena o retorno do método BuscarFuncionario(), que é uma string de comando MySql. 
            string strMysql = funcionarioDao.BuscarFuncionario(matricula);
            // A string strMysql é passada por parâmetro para que o método ExibirNoDataGridView() possa fazer a conexão com o banco e exibir os dados buscados no DataGridView
            dataGridListar.DataSource = funcionarioDao.ExibirNoDataGridView(strMysql);
        }

        private void ToolStripButtonEditar_Click(object sender, EventArgs e)
        {
            // Abre o form EditarCadastroFuncionario
            EditarCadastroFuncionario editarCadastroFuncionario = new EditarCadastroFuncionario();
            editarCadastroFuncionario.Show();
        }

        private void ToolStripButtonListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        private void DataGridListar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void ToolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void LblTituloForm_Click(object sender, EventArgs e)
        {

        }

        private void ListarFuncionario_Load(object sender, EventArgs e)
        {

        }
    }
}
