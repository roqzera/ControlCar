﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PimForms.Classes;
using PimForms.SubMenus;

namespace PimForms.Formulários
{
    public partial class CadastrarFuncionario : Form
    {
        Formularios form = new Formularios();

        public CadastrarFuncionario()
        {           
            InitializeComponent();
        }

        private void CadastrarFuncionario_Load(object sender, EventArgs e)
        {

        }

        private void BtnAdicionar_Click(object sender, EventArgs e)
        {
            Funcionario funcionario = new Funcionario(txtMatricula.Text,
                txtNome.Text,
                maskCPF.Text,
                maskDataNascimento.Text,
                maskTelefone.Text,
                txtCargo.Text,
                txtEmail.Text,
                txtNumeroCNH.Text,
                txtCategoriaCNH.Text,
                maskValidadeCNH.Text
                );

            GerenciadorFuncionario gerenciadorFuncionario = new GerenciadorFuncionario();
            gerenciadorFuncionario.AdicionarFuncionario(funcionario);

            txtMatricula.Text = string.Empty;
            txtNome.Text = string.Empty;
            maskCPF.Text = string.Empty;
            maskDataNascimento.Text = string.Empty;
            maskTelefone.Text = string.Empty;
            txtCargo.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtNumeroCNH.Text = string.Empty;
            txtCategoriaCNH.Text = string.Empty;
            maskValidadeCNH.Text = string.Empty;

        }

        private void LblTituloForm_Click(object sender, EventArgs e)
        {
            
        }
    }
}
