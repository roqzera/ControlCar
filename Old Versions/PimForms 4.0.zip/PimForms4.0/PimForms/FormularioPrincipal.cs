﻿using PimForms.models;
using PimForms.SubMenus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PimForms
{

    public partial class FormularioPrincipal : Form
    {
        public FormularioPrincipal()
        {
            InitializeComponent();
        }

        Formularios form = new Formularios();

        public void button5_Click(object sender, EventArgs e)
        {
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }



        private void button2_BackgroundImageChanged(object sender, EventArgs e)
        {
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
        }

        private void btnViagem_Click(object sender, EventArgs e)
        {
        }

        private void btnVeiculo_Click(object sender, EventArgs e)
        {
            form.AbrirSubMenu<FormSubMenuVeiculos>(painelFormPrincipal);
            MudaCorBtn(btnVeiculo, btnViagem, btnFuncionario, PimForms.Properties.Resources.iconecarrogray85x80, PimForms.Properties.Resources.iconeviagem85x80, PimForms.Properties.Resources.iconeusuarioBranco85x80);


        }

        public void MudaCorBtn(Button button1, Button button2, Button button3, Image img1, Image img2, Image img3)
        {
            button1.Enabled = true;

            if (Enabled == true)
            {
                button1.BackColor = Color.LightGray;
                button1.Image = img1;
                button1.ForeColor = Color.DimGray;

                button2.BackColor = Color.DarkSeaGreen;
                button2.Image = img2;
                button2.ForeColor = Color.White;

                button3.BackColor = Color.DarkSeaGreen;
                button3.Image = img3;
                button3.ForeColor = Color.White;

            }
        }

        private void button5_Click_2(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnViagem_Click_1(object sender, EventArgs e)
        {
            form.AbrirSubMenu<FormSubMenuViagem>(painelFormPrincipal);
            
            MudaCorBtn(btnViagem, btnVeiculo, btnFuncionario, PimForms.Properties.Resources.iconeviagemgray85x80, PimForms.Properties.Resources.iconecarro85x80, PimForms.Properties.Resources.iconeusuarioBranco85x80);

        }

        private void painelFormPrincipal_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnFuncionario_Click(object sender, EventArgs e)
        {
            form.AbrirSubMenu<FormSubMenuFuncionario>(painelFormPrincipal);
            MudaCorBtn(btnFuncionario, btnViagem, btnVeiculo, PimForms.Properties.Resources.iconeusuarioDimGray85x80, PimForms.Properties.Resources.iconeviagem85x80, PimForms.Properties.Resources.iconecarro85x80);

        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
