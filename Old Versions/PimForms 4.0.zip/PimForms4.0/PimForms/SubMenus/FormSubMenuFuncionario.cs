﻿using PimForms.Formulários;
using PimForms.SubMenus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PimForms.models
{
    public partial class FormSubMenuFuncionario : Form
    {
        Formularios form = new Formularios();
        public FormSubMenuFuncionario()
        {
            InitializeComponent();
        }

        private void Panel10_Paint(object sender, PaintEventArgs e)
        {

        }

        private void TableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnSubMenu1_Click(object sender, EventArgs e)
        {
            form.AbrirSubMenu<CadastrarFuncionario>(pnlFormularios);
        }

        private void BtnConsultarSubMenuFuncionario_Click(object sender, EventArgs e)
        {
            form.AbrirSubMenu<ListarFuncionario>(pnlFormularios);
        }
    }
}
