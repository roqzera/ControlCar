﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class Teste
    {
        private string _numeroCNH;
        private DateTime _validadeCNH;
        private string _categoriaCNH;

        public string CategoriaCNH
        {
            get { return _categoriaCNH; }
            set { _categoriaCNH = value; }
        }


        public string NumeroCNH
        {
            get { return _numeroCNH; }
            set { _numeroCNH = value; }
        }

        
        public DateTime ValidadeCNH
        {
            get { return _validadeCNH; }
            set
            {
                if (IsValidadeCNH(value) == false)
                {
                    DateTime dateTime = new DateTime();
                    _validadeCNH = dateTime;
                }
                else
                {
                    _validadeCNH = value;
                }
            }
        }

        private bool IsValidadeCNH(DateTime dateTime)
        {
            DateTime data;
            string strData = Convert.ToString(dateTime);

            if (DateTime.TryParse(strData, out data))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
