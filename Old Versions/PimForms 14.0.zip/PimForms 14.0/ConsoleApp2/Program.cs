﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace ConsoleApp2
{
    public class Program
    {
        static void Main(string[] args)
        {
            DateTime dateTime = new DateTime();
            string strData = "02/02/2000";

            if (DateTime.TryParseExact(strData, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime date))
            {
                Convert.ToDateTime(strData);
            }
            else
            {
                strData = Convert.ToString(dateTime);
            }

            Teste teste2 = new Teste();
            Console.WriteLine(teste2.NumeroCNH);
            Console.WriteLine(teste2.CategoriaCNH);
            Console.WriteLine(teste2.ValidadeCNH);

            Teste teste = new Teste()
            {
                NumeroCNH = null,
                CategoriaCNH = "AB",
                ValidadeCNH = Convert.ToDateTime(strData)
            };

            if (((teste.NumeroCNH == null) && (Convert.ToString(teste.ValidadeCNH) == "01/01/0001 00:00:00") && (teste.CategoriaCNH == null))
                || ((teste.NumeroCNH != null) && (Convert.ToString(teste.ValidadeCNH) != "01/01/0001 00:00:00") && (teste.CategoriaCNH != null)))
            {
                Console.WriteLine("Passou");
            }
            else
            {
                Console.WriteLine("Não passou");
            }

            Console.WriteLine(teste.ValidadeCNH.GetType());
            Console.WriteLine(teste.ValidadeCNH);

            Console.ReadKey();
        }
    }
}
