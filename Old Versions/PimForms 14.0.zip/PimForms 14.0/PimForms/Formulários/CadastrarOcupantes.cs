﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PimForms.Classes;

namespace PimForms.Formulários
{
    public partial class CadastrarOcupantes : Form
    {
        public CadastrarOcupantes()
        {
            InitializeComponent();
        }

        private void CadastrarOcupantes_Load(object sender, EventArgs e)
        {

        }

        private void BtnAdicionar_Click(object sender, EventArgs e)
        {

        }

        private void BtnAdicionarOcupante_Click(object sender, EventArgs e)
        {
            FuncionarioDao funcionarioDao = new FuncionarioDao();
            {
                Convert.ToInt32(funcionarioDao.BuscarIdFuncionario(txtNomeOcupante.Text)
            };
        }
    }
}
