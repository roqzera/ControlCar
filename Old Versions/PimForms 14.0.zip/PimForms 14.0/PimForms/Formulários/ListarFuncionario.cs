﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PimForms.Classes;
using PimForms.SubMenus;
using PimForms.Formulários;

namespace PimForms.Formulários
{
    public partial class ListarFuncionario : Form
    {
        public ListarFuncionario()
        {
            InitializeComponent();
            Listar();
        }

        Formularios form = new Formularios();

        // Método usado para listar todos os funcionários cadastrados no DataGridView assim que o form EditarCadastroFuncionario é inicializado
        public void Listar()
        {
            FuncionarioDao funcionarios = new FuncionarioDao();
            dataGridListar.DataSource = funcionarios.ListarFuncionario();

        }

        private void ToolStripButtonPesquisar_Click(object sender, EventArgs e)
        {
            string matricula = Convert.ToString(toolStripTextBoxMatricula.Text);

            FuncionarioDao funcionarios = new FuncionarioDao();
            dataGridListar.DataSource = funcionarios.BuscarFuncionario(matricula);
        }

        private void ToolStripButtonEditar_Click(object sender, EventArgs e)
        {
            // Abre o form EditarCadastroFuncionario
            EditarCadastroFuncionario editarCadastroFuncionario = new EditarCadastroFuncionario();

            if (dataGridListar.SelectedRows.Count > 0)
            {
                FuncionarioDao funcionarios = new FuncionarioDao();

                editarCadastroFuncionario.txtMatriculaEditarCadastro.Text = dataGridListar.CurrentRow.Cells["matricula"].Value.ToString();
                editarCadastroFuncionario.txtNomeEditarCadastro.Text = dataGridListar.CurrentRow.Cells["nome"].Value.ToString();
                editarCadastroFuncionario.maskCpfEditarCadastro.Text = dataGridListar.CurrentRow.Cells["cpf"].Value.ToString();
                editarCadastroFuncionario.maskDataNascimentoEditar.Text = dataGridListar.CurrentRow.Cells["datadenascimento"].Value.ToString();
                editarCadastroFuncionario.maskTelefoneEditarCadastro.Text = dataGridListar.CurrentRow.Cells["telefone"].Value.ToString();
                editarCadastroFuncionario.txtCargoEditarCadastro.Text = dataGridListar.CurrentRow.Cells["cargo"].Value.ToString();
                editarCadastroFuncionario.txtEmailEditarCadastro.Text = dataGridListar.CurrentRow.Cells["email"].Value.ToString();
                editarCadastroFuncionario.txtNumeroCnhEditarCadastro.Text = dataGridListar.CurrentRow.Cells["numerocnh"].Value.ToString();
                editarCadastroFuncionario.txtCategoriaCnhEditarCadastro.Text = dataGridListar.CurrentRow.Cells["CategoriaCNH"].Value.ToString();
                editarCadastroFuncionario.maskValidadeCnhEditarCadastro.Text = dataGridListar.CurrentRow.Cells["validadecnh"].Value.ToString();
                editarCadastroFuncionario.maskValidadeCnhEditarCadastro.Text = dataGridListar.CurrentRow.Cells["motorista"].Value.ToString();
                editarCadastroFuncionario.lblId.Text = funcionarios.BuscarIdFuncionario(dataGridListar.CurrentRow.Cells["nome"].Value.ToString());
            }

            editarCadastroFuncionario.Show();
        }

        private void ToolStripButtonListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        private void DataGridListar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            Listar();
        }

        private void ToolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void LblTituloForm_Click(object sender, EventArgs e)
        {

        }

        private void ListarFuncionario_Load(object sender, EventArgs e)
        {

        }

        private void ToolStripTextBoxMatricula_Click(object sender, EventArgs e)
        {

        }

        private void DataGridListar_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ToolStripButtonExcluir_Click(object sender, EventArgs e)
        {
            string idFuncionario;

            if (dataGridListar.SelectedRows.Count > 0)
            { 
            FuncionarioDao funcionarioDao = new FuncionarioDao();
            idFuncionario = funcionarioDao.BuscarIdFuncionario(dataGridListar.CurrentRow.Cells["nome"].Value.ToString());
            funcionarioDao.ExcluirFuncionario(idFuncionario);
            }

            Listar();
        }
    }
}
