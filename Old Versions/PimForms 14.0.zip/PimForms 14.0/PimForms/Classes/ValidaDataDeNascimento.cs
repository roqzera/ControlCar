﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PimForms.Classes
{
    public class ValidaDataDeNascimento
    {
        public bool IsDataMesFevereiro(string ano, string mes, string dia)
        {
            if (ConverteAno(ano) > 1939 && ConverteAno(ano) <= 2001)
            {
                if ((VerificaDataMesDeFevereiro(ano, mes, dia) == true
               && VerificaDataComMesDe30Dias(ano, mes, dia) == false
               && VerificaDataComMesDe31Dias(ano, mes, dia) == false) == true)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public bool IsDataComMesDe30Dias(string ano, string mes, string dia)
        {
            if (ConverteAno(ano) > 1939 && ConverteAno(ano) <= 2001)
            {
                if ((VerificaDataMesDeFevereiro(ano, mes, dia) == false
                   && VerificaDataComMesDe30Dias(ano, mes, dia) == true
                   && VerificaDataComMesDe31Dias(ano, mes, dia) == false) == true)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public bool IsDataComMesDe31Dias(string ano, string mes, string dia)
        {
            if (ConverteAno(ano) > 1939 && ConverteAno(ano) <= 2001)
            {
                if ((VerificaDataMesDeFevereiro(ano, mes, dia) == false
                    && VerificaDataComMesDe30Dias(ano, mes, dia) == false
                    && VerificaDataComMesDe31Dias(ano, mes, dia)) == true)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public bool VerificaDataMesDeFevereiro(string ano, string mes, string dia)
        {
            if (((mes == "02") && (ConverteDia(dia) > 0) && (QuantidadeDeDiasDoMes(ano, mes) >= ConverteDia(dia))) == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool VerificaDataComMesDe30Dias(string ano, string mes, string dia)
        {
            if (((mes == "04" || mes == "06" || mes == "09" || mes == "11")
                && (ConverteDia(dia) > 0) && QuantidadeDeDiasDoMes(ano, mes) >= ConverteDia(dia)) == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool VerificaDataComMesDe31Dias(string ano, string mes, string dia)
        {
            if (((mes == "01" || mes == "03" || mes == "05" || mes == "07" || mes == "08" || mes == "10" || mes == "12")
                && (ConverteDia(dia) > 0) && QuantidadeDeDiasDoMes(ano, mes) >= ConverteDia(dia)) == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int QuantidadeDeDiasDoMes(string ano, string mes)
        {
            return DateTime.DaysInMonth(ConverteAno(ano), ConverteMes(mes));
        }

        public int ConverteDia(string dia)
        {
            int diaData = Convert.ToInt16(dia);
            return diaData;
        }

        public int ConverteMes(string mes)
        {
            int mesData = Convert.ToInt16(mes);
            return mesData;
        }

        public int ConverteAno(string ano)
        {
            int anoData = Convert.ToInt16(ano);
            return anoData;
        }
    }
}

