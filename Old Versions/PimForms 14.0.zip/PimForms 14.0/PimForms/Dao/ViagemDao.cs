﻿using MySql.Data.MySqlClient;
using PimForms.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PimForms.Dao
{
    class ViagemDao
    {
        MySqlCommand cmd = new MySqlCommand();
        ConexaoBanco conexao = new ConexaoBanco();
        MySqlConnection mySqlConnection;

        public void AdicionarViagem(Viagem viagem)
        {

            //Comando Sql: insert, update, delete

            cmd.CommandText = "INSERT INTO viagem (data_saida, data_retorno, destino, valor_adiantamento, km_inicial, km_final, id_veiculo) " +
                "VALUES (@DataSaida, @DataRetorno, @Destino, @ValorAdiantamento, @KmInicial, @KmFinal, @IdVeiculo)";

            //Parametros
            cmd.Parameters.AddWithValue("@DataSaida", viagem.DataSaida);
            cmd.Parameters.AddWithValue("@DataRetorno", viagem.DataRetorno);
            cmd.Parameters.AddWithValue("@Destino", viagem.Destino);
            cmd.Parameters.AddWithValue("@ValorAdiantamento", viagem.ValorAdiantamento);
            cmd.Parameters.AddWithValue("@KmInicial", viagem.KmInicial);
            cmd.Parameters.AddWithValue("@KmFinal", viagem.KmFinal);
            cmd.Parameters.AddWithValue("@IdVeiculo", viagem.IdVeiculo);

            try
            {
                //Conectar com o banco
                cmd.Connection = conexao.Conectar();
                //Executar Comando
                cmd.ExecuteNonQuery();
                //Desconectar
                conexao.Desconectar();
                //Mostrar mensagem de sucesso/erro
                MessageBox.Show("Cadastro realizado com sucesso!");
            }

            catch (MySqlException)
            {
                //MessageBox.Show("Erro ao tentar se conectar com o banco de dados");
                //throw ex;
            }

            finally
            {
                conexao.Desconectar();
            }
        }

        public string ListarViagens()
        {
            string strMysql = "SELECT * FROM viagem";

            return strMysql;
        }

        public string FiltrarViagemVeiculo(string placa)
        {

            string strMysql = "SELECT * FROM veiculo_viagem WHERE placa = @placa;";
            cmd.Parameters.AddWithValue("@placa", placa);

            return strMysql;
        }
        public string FiltrarViagemFuncionario(string matricula)
        {

            string strMysql = "SELECT * FROM funcionario_viagem WHERE matricula = @matricula;";
            cmd.Parameters.AddWithValue("@matricula", matricula);

            return strMysql;
        }
    }
}
